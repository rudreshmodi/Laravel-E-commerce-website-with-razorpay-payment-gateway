<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-commerce Shopping | Verify OTP</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <!-- Include Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>

<body class="bg-gray-100 flex items-center justify-center h-screen">

    <!-- OTP Verification Form -->
    <div class="bg-white shadow-md rounded-lg p-6 w-full max-w-md">
        <h2 class="text-2xl font-bold text-center mb-4">Verify OTP</h2>

        <?php if(session('success')): ?>
        <div id="successToast"
            class="fixed top-10 right-10 z-50 bg-green-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
            <!-- Success Icon -->
            <i class="fas fa-check-circle text-white text-2xl"></i>
            <!-- Success Message -->
            <span><?php echo e(session('success')); ?></span>
        </div>

        <script>
            setTimeout(() => {
                document.querySelector('#successToast').style.display = 'none';
            }, 4000);
        </script>
        <?php endif; ?>

        <!-- Error Toast -->
        <?php if(session('error')): ?>
        <div id="errorToast"
            class="fixed top-10 right-10 z-50 bg-red-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
            <!-- Error Icon -->
            <i class="fas fa-times-circle text-white text-2xl"></i>
            <!-- Error Message -->
            <span><?php echo e(session('error')); ?></span>
        </div>

        <script>
            setTimeout(() => {
                document.querySelector('#errorToast').style.display = 'none';
            }, 4000);
        </script>
        <?php endif; ?>

        <form action="<?php echo e(route('otp.verify')); ?>" method="POST" class="space-y-4">
            <?php echo csrf_field(); ?>

            <!-- OTP Input with Space Formatting -->
            <div class="mb-6">
                <label for="otp-input" class="block text-sm font-medium text-gray-700">OTP <span
                        class="text-red-500">*</span></label>
                <div class="relative">
                    <input type="text" id="otp-input" name="otp" maxlength="6" 
                    class="mt-1 block w-full px-4 py-2 pr-10 border border-gray-300 rounded-md shadow-sm
                    focus:outline-none focus:ring-2 focus:ring-blue-500 text-center"
                    required
                    autofocus
                    oninput="handleInput(event)"
                    onkeydown="moveBackFocus(event, null)"
                    placeholder=" _ _ _ _ _ _">
                    <i class="fas fa-shield-alt absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 text-semibold"
                        style="font-size: 24px; font-family:'Times New Roman', Times, serif; font-weight:900;"></i>
                </div>

                <!-- OTP Counter Display -->
                <div class="flex justify-end text-sm text-gray-500 mt-1">
                    <span id="otp-counter">0</span> / 6
                </div>
            </div>

            <?php $__errorArgs = ['otp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="mt-2 text-sm text-red-500"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <!-- Verify OTP Button (Initially disabled) -->
            <button type="submit" id="verify-otp-btn"
                class="w-full bg-blue-500 text-white py-2 rounded hover:bg-blue-600 transition disabled:opacity-50"
                disabled>
                Verify OTP
            </button>
        </form>

        <div class="mt-4 text-center">
            <p class="text-gray-700">Didn't receive the OTP? <a href="<?php echo e(route('otp.resend')); ?>"
                    class="text-blue-500 hover:underline">Resend OTP</a></p>
        </div>
    </div>

    <script>
        // Move focus to the next field when a digit is entered
        function moveFocus(event, nextField) {
            if (event.target.value.length === 1 && nextField) {
                nextField.focus();
            }
        }

        // Move focus to the previous field when backspace is pressed
        function moveBackFocus(event, prevField) {
            if (event.key === "Backspace" && event.target.value.length === 0 && prevField) {
                prevField.focus();
            }
        }

        // Handle OTP input and update counter, add space after each digit
        function handleInput(event) {
            let inputValue = event.target.value.replace(/\D/g, ''); // Remove non-digit characters
            let formattedValue = inputValue.split('').join(''); // Add space between digits
            event.target.value = formattedValue.slice(0, 6); // Limit input to 11 characters (6 digits + 5 spaces)

            // Update the OTP counter display
            updateCounter(inputValue.length);

            // Enable or disable the "Verify OTP" button based on OTP length
            toggleSubmitButton(inputValue.length);
        }

        // Update the OTP counter display (e.g., 3 / 6)
        function updateCounter(count) {
            const counterElement = document.getElementById('otp-counter');
            counterElement.innerText = `${count}`;
        }

        // Enable/Disable the "Verify OTP" button based on OTP length
        function toggleSubmitButton(count) {
            const submitButton = document.getElementById('verify-otp-btn');

            // Enable the button if the OTP length is 6, otherwise disable it
            if (count === 6) {
                submitButton.disabled = false;
                submitButton.classList.remove('disabled:opacity-50');
            } else {
                submitButton.disabled = true;
                submitButton.classList.add('disabled:opacity-50');
            }
        }


    </script>

</body>

</html>
<?php /**PATH /opt/lampp/htdocs/Rudresh/razorpay/resources/views/auth/verify-otp.blade.php ENDPATH**/ ?>