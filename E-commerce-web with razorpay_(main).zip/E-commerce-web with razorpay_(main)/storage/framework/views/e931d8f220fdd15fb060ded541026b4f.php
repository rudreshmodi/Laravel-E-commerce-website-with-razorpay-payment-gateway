<?php $__env->startSection('title', 'Edit Combo'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Breadcrumb -->
    <div class="flex px-5 py-3 text-gray-700 border border-gray-200 rounded-lg bg-gray-50 dark:bg-gray-800 dark:border-gray-700"
        aria-label="Breadcrumb">
        <ol class="inline-flex items-center space-x-1 md:space-x-2 rtl:space-x-reverse">
            <!-- Home Breadcrumb -->
            <li class="inline-flex items-center">
                <a href="<?php echo e(route('dashboard')); ?>"
                    class="inline-flex items-center text-sm font-medium text-gray-700 hover:text-blue-600 dark:text-gray-400 dark:hover:text-white">
                    <svg class="w-3 h-3 me-2.5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor"
                        viewBox="0 0 20 20">
                        <path
                            d="m19.707 9.293-2-2-7-7a1 1 0 0 0-1.414 0l-7 7-2 2a1 1 0 0 0 1.414 1.414L2 10.414V18a2 2 0 0 0 2 2h3a1 1 0 0 0 1-1v-4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v4a1 1 0 0 0 1 1h3a2 2 0 0 0 2-2v-7.586l.293.293a1 1 0 0 0 1.414-1.414Z" />
                    </svg>
                    Home
                </a>
            </li>

            <!-- Separator -->
            <li>
                <div class="flex items-center">
                    <svg class="rtl:rotate-180 block w-3 h-3 mx-1 text-gray-400" aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="m1 9 4-4-4-4" />
                    </svg>
                    <a href="<?php echo e(route('categories.index')); ?>"
                        class="ms-1 text-sm font-medium text-gray-700 hover:text-blue-600 md:ms-2 dark:text-gray-400 dark:hover:text-white">Categories</a>
                </div>
            </li>

            <!-- Separator -->
            <li>
                <div class="flex items-center">
                    <svg class="rtl:rotate-180 block w-3 h-3 mx-1 text-gray-400" aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="m1 9 4-4-4-4" />
                    </svg>
                    <span class="ms-1 text-sm font-medium text-gray-500 md:ms-2 dark:text-gray-400">Edit</span>
                </div>
            </li>
        </ol>
    </div>
    <div class="container mx-auto mt-0">

        <!-- Form Container -->
        <div class="w-full bg-white p-8 rounded-lg shadow-xl">
            <div class="flex justify-between items-center mb-6">
                <h2 class="text-3xl font-semibold text-gray-800"><i class="fas fa-edit mr-2"></i> Edit Combo</h2>
            </div>

            <!-- Combo Form -->
            <form action="<?php echo e(route('combos.update', $combo->id)); ?>" method="POST" enctype="multipart/form-data"
                class="space-y-6">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <!-- Combo Name and Total Price -->
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <!-- Combo Name -->
                    <div class="mb-4 relative">
                        <label for="name" class="block text-sm font-medium text-gray-700">Combo Name <span
                                class="text-red-500">*</span></label>
                        <input type="text" name="name" id="name" value="<?php echo e(old('name', $combo->name)); ?>"
                            class="mt-1 block w-full px-4 py-2 pr-10 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <i class="fas fa-pen absolute right-3 text-gray-500" style="top:40px;"></i>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-2 text-sm text-red-500"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Total Price Section with Modal Button -->
                    <div class="mb-6 relative">
                        <label for="total_price" class="block text-sm font-medium text-gray-800 mb-2">Total Price <span
                                class="text-red-500">*</span></label>
                        <div
                            class="mt-2 flex items-center justify-between px-4 py-2 border border-gray-300 rounded-xl shadow-lg bg-white hover:bg-gray-50 transition duration-300 ease-in-out">
                            <span class="text-lg font-semibold text-gray-800">Total:</span>
                            <span class="text-xl font-bold text-blue-600"
                                id="total_price_display">₹<?php echo e(number_format(old('total_price', $combo->total_price), 2)); ?></span>
                            <div class="flex items-center space-x-2">
                                <button type="button" id="view-products-modal"
                                    class="flex items-center text-sm font-medium text-blue-600 hover:text-blue-500 transition duration-200 ease-in-out">
                                    <i class="fa-solid fa-calculator mr-2"></i>Discount
                                </button>
                            </div>
                        </div>
                        <input type="hidden" name="total_price" id="total_price"
                            value="<?php echo e(old('total_price', $combo->total_price)); ?>">

                        <!-- Tooltip or helper text below the button -->
                        <p class="mt-2 text-xs text-gray-700 bg-gray-50 border-l-4 border-blue-500 p-2 rounded-md">
                            Click the "Discount" button to apply any available discounts to your total price.
                        </p>

                    </div>

                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <!-- Category Selection -->
                    <div class="mb-4 relative">
                        <label for="categories_id" class="block text-sm font-medium text-gray-700">Category</label>
                        <select name="categories_id" id="category_id"
                            class="mt-1 block w-full px-4 py-2 pr-10 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                            <option value="" disabled>Select a Category</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"
                                    <?php echo e($category->id == old('categories_id', $combo->category_id) ? 'selected' : ''); ?>>
                                    <?php echo e($category->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['categories_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-2 text-sm text-red-500"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>



                    <!-- Subcategory Selection -->
                    <div>
                        <label for="subcategory_id" class="block text-sm font-medium text-gray-700">Subcategory</label>
                        <select name="subcategory_id" id="subcategory_id"
                            class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md" required>
                            <option value="">Select Subcategory</option>
                            <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($subcategory->id); ?>"
                                    <?php echo e($combo->subcategory_id == $subcategory->id ? 'selected' : ''); ?>>
                                    <?php echo e($subcategory->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['subcategory_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-xs mt-2"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>


                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <!-- Product Selection (Custom Dropdown with Checkboxes) -->
                    <div class="mb-4 relative">
                        <label for="products" class="block text-sm font-medium text-gray-700">Products</label>

                        <!-- Custom Dropdown for Products with Checkboxes -->
                        <div id="product-dropdown" class="relative">
                            <button id="dropdown-toggle" type="button"
                                class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 flex justify-between items-baseline bg-gray-100 text-black text-start hover:bg-gray-50">
                                <span class="flex-grow">Select Products</span>
                                <span id="dropdown-icon"
                                    style="text-align:right; font-size:11px; margin-left: 56px; margin-top:-10px; color:black; font-weight: bold;">
                                    <i class="fas fa-chevron-down"></i>
                                </span>
                            </button>

                            <!-- Product Counter Display -->
                            <div class="absolute -top-10 right-0 mt-1 mr-4 text-sm font-bold text-blue-600"
                                id="product-counter">
                                Selected Products: <?php echo e(count($combo->products)); ?>

                            </div>

                            <!-- Dropdown Menu -->
                            <div id="dropdown-menu"
                                class="absolute z-10 hidden bg-white border border-gray-300 rounded-md shadow-md w-full mt-1 max-h-60 overflow-y-auto transition-all ease-in-out duration-300 transform origin-top">
                                <div class="py-2">
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <label class="block px-4 py-2 cursor-pointer hover:bg-gray-100 product-option">
                                            <input type="checkbox" name="products[]" value="<?php echo e($product->id); ?>"
                                                data-price="<?php echo e($product->price); ?>" class="product-checkbox"
                                                <?php echo e($combo->products->contains($product->id) ? 'checked' : ''); ?>>
                                            <?php echo e($product->name); ?>

                                        </label>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                        <?php $__errorArgs = ['products'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-2 text-sm text-red-500"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Discount Price -->
                    <div class="mb-4 relative">
                        <label for="disc_price" class="block text-sm font-medium text-gray-700">Discount Price</label>
                        <input type="text" name="disc_price" id="disc_price"
                            value="<?php echo e(old('disc_price', $combo->disc_price)); ?>"
                            class="mt-1 block w-full px-4 py-2 pr-10 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <i class="fas fa-percent absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500"></i>
                        <p class="mt-2 text-sm text-gray-500" id="discounted-price">Suggested Discount Price:
                            ₹<?php echo e(number_format($combo->disc_price, 2)); ?>(10%)</p>
                        <?php $__errorArgs = ['disc_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-2 text-sm text-red-500"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <!-- Combo Description -->
                <div class="mb-4 relative">
                    <label for="description" class="block text-sm font-medium text-gray-700">Combo Description</label>
                    <div class="relative">
                        <textarea name="description" id="description" rows="3" maxlength="150" oninput="updateCharCount()"
                            class="mt-1 block w-full px-4 py-2 pr-10 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"><?php echo e(old('description', $combo->description)); ?></textarea>
                        <i class="fas fa-pencil-alt absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                    </div>
                    <div class="right-18 text-sm text-gray-500 mt-1">
                        <span id="charCount">0</span> / 100
                    </div>
                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-2 text-sm text-red-500"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Image Upload -->
                <div class="mb-4 relative">
                    <label for="image" class="block text-sm font-medium text-gray-700">Combo Image</label>
                    <input type="file" name="image" id="image" accept="image/*"
                        class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">

                    <!-- Image Preview -->
                    <?php if($combo->image): ?>
                        <div class="mt-2">
                            <p class="text-sm text-gray-600">Current Image:</p>
                            <img src="<?php echo e(asset('storage/' . $combo->image)); ?>" alt="Combo Image"
                                class="mt-2 w-28 border-2 border-blue-400 rounded-lg h-auto object-cover">
                        </div>
                    <?php endif; ?>

                    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-2 text-sm text-red-500"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Buttons -->
                <div class="flex justify-end gap-4 mt-6">
                    <a href="<?php echo e(route('combos.index')); ?>"
                        class="bg-gray-300 text-gray-800 px-4 py-2 rounded-md hover:bg-gray-400 transition"><i
                            class="fas fa-times-circle mr-2"></i> Cancel</a>
                    <button type="submit"
                        class="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 transition"><i
                            class="fas fa-save mr-2"></i> Save Changes</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Product Details Modal -->
    <div id="product-modal" class="fixed inset-0 bg-gray-800 bg-opacity-50 hidden flex justify-center items-center z-50">
        <div class="bg-white p-6 rounded-lg shadow-xl w-full sm:w-1/3">
            <h3 class="text-xl font-semibold mb-4">Selected Products</h3>
            <div class="mt-4">
                <label for="discount-select" class="block text-sm font-medium text-gray-700">Select Discount</label>
                <select id="discount-select"
                    class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <option value="0" selected>No Discount</option>
                    <option value="5">5%</option>
                    <option value="10">10%</option>
                    <option value="15">15%</option>
                    <option value="20">20%</option>
                    <option value="25">25%</option>
                    <option value="30">30%</option>
                    <option value="35">35%</option>
                    <option value="40">40%</option>
                </select>
                <p class="mt-2 text-sm text-gray-600" id="discounted-price-text">Discounted Price: ₹0.00</p>
            </div>

            <div class="mt-6 flex justify-between">
                <button type="button" id="close-modal"
                    class="bg-gray-300 text-gray-800 px-4 py-2 rounded-md hover:bg-gray-400">Close</button>
                <button type="button" id="apply-discount"
                    class="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700">Apply Discount</button>
            </div>
        </div>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const productCheckboxes = document.querySelectorAll('.product-checkbox');
            const totalPriceDisplay = document.getElementById('total_price_display');
            const totalPriceInput = document.getElementById('total_price');
            const productCounter = document.getElementById('product-counter');
            const discountSelect = document.getElementById('discount-select');
            const discountedPriceText = document.getElementById('discounted-price-text');
            const applyDiscountButton = document.getElementById('apply-discount');
            const viewProductsModal = document.getElementById('view-products-modal');
            const productModal = document.getElementById('product-modal');
            const closeModalButton = document.getElementById('close-modal');

            let selectedProducts = [];
            const minSelection = 2;
            const maxSelection = 6;

            // Function to update the total price based on selected products and discount
            function updateTotalPrice() {
                let totalPrice = 0;
                let discount = parseFloat(discountSelect.value);

                // Loop through each selected product and add its price
                document.querySelectorAll('.product-checkbox:checked').forEach(item => {
                    totalPrice += parseFloat(item.dataset.price);
                });

                // Apply discount if any
                totalPrice = totalPrice - (totalPrice * (discount / 100));

                // Update total price input field and display
                totalPriceInput.value = totalPrice.toFixed(2);
                totalPriceDisplay.textContent = `₹${totalPrice.toFixed(2)}`;
                discountedPriceText.textContent =
                    `Discounted Price: ₹${totalPrice.toFixed(2)}`;
            }

            // Event listener for product selection
            productCheckboxes.forEach(item => {
                item.addEventListener('change', function() {
                    let selectedCount = [...productCheckboxes].filter(checkbox => checkbox.checked)
                        .length;
                    productCounter.textContent = `Selected Products: ${selectedCount}`;

                    if (selectedCount >= minSelection && selectedCount <= maxSelection) {
                        updateTotalPrice();
                        productCounter.classList.remove('text-red-500');
                    } else {
                        productCounter.classList.add('text-red-500');
                    }
                });
            });

            // Apply discount functionality
            applyDiscountButton.addEventListener('click', function() {
                updateTotalPrice();
                productModal.classList.add('hidden');
            });

            // Open product selection modal
            viewProductsModal.addEventListener('click', function() {
                productModal.classList.remove('hidden');
            });

            // Close product selection modal
            closeModalButton.addEventListener('click', function() {
                productModal.classList.add('hidden');
            });
        });
    </script>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const dropdownToggle = document.getElementById('dropdown-toggle');
            const dropdownMenu = document.getElementById('dropdown-menu');
            const dropdownIcon = document.getElementById('dropdown-icon');
            const productCheckboxes = dropdownMenu.querySelectorAll('input[type="checkbox"]');
            const totalPriceDisplay = document.getElementById('total_price_display');
            const totalPriceInput = document.getElementById('total_price');
            const productCounter = document.getElementById('product-counter');
            const productModal = document.getElementById('product-modal');
            const productList = document.getElementById('product-list');
            const discountSelect = document.getElementById('discount-select');
            const discountedPriceText = document.getElementById('discounted-price-text');
            const viewProductsModal = document.getElementById('view-products-modal');
            const closeModal = document.getElementById('close-modal');
            const applyDiscount = document.getElementById('apply-discount');
            const fileInput = document.getElementById('image');
            const imagePreviewContainer = document.getElementById('image-preview-container');
            const imagePreview = document.getElementById('image-preview');
            const discountPriceInput = document.getElementById('disc_price');
            const charCount = document.getElementById('charCount');
            const categoryId = document.getElementById('category_id');
            const subcategoryDropdown = document.getElementById('subcategory_id');

            let selectedProducts = [];
            const minSelection = 2;
            const maxSelection = 6;

            // Show and hide the modal for product selection
            viewProductsModal.addEventListener('click', () => productModal.classList.remove('hidden'));
            closeModal.addEventListener('click', () => {
                productModal.classList.add('hidden');
                // Clear selected products and reset fields when modal is closed
                productCheckboxes.forEach(checkbox => checkbox.checked = false);
                productList.innerHTML = '';
                totalPriceDisplay.textContent = '₹0.00';
                totalPriceInput.value = '0.00';
                productCounter.textContent = `Selected Products: 0`;
                discountedPriceText.textContent = `Discounted Price: ₹0.00`;
            });

            // Function to load subcategories based on selected category
            function loadSubcategories(categoryId) {
                subcategoryDropdown.innerHTML =
                    '<option value="">Select Subcategory</option>'; // Reset subcategories dropdown
                if (!categoryId) return;

                fetch(`/get-subcategories/${categoryId}`)
                    .then(response => response.json())
                    .then(data => {
                        data.forEach(subcategory => {
                            const option = document.createElement('option');
                            option.value = subcategory.id;
                            option.textContent = subcategory.name;
                            subcategoryDropdown.appendChild(option);
                        });

                        // Ensure old value is selected
                        const oldSubcategoryId = '<?php echo e(old('subcategories_id', $combo->subcategories_id)); ?>';
                        if (oldSubcategoryId) {
                            subcategoryDropdown.value = oldSubcategoryId; // Set the old value as selected
                        }
                    })
                    .catch(error => console.error('Error fetching subcategories:', error));
            }

            // Load subcategories on page load if a category is already selected
            if (categoryId.value) {
                loadSubcategories(categoryId.value);
            }

            // Category change event to update subcategories dynamically
            categoryId.addEventListener('change', function() {
                loadSubcategories(this.value);
            });

            // Update total price and selected product count
            productCheckboxes.forEach(checkbox => {
                checkbox.addEventListener('change', function() {
                    let totalPrice = 0,
                        selectedCount = 0;
                    selectedProducts = [];
                    productCheckboxes.forEach(checkbox => {
                        if (checkbox.checked) {
                            selectedCount++;
                            selectedProducts.push({
                                name: checkbox.parentElement.textContent.trim(),
                                price: parseFloat(checkbox.getAttribute(
                                    'data-price'))
                            });
                            totalPrice += parseFloat(checkbox.getAttribute('data-price'));
                        }
                    });

                    productList.innerHTML = selectedProducts.map(product =>
                        `<tr><td class="py-2 px-4 text-sm text-black">${product.name}</td><td class="py-2 px-4 text-blue-700">₹${product.price.toFixed(2)}</td></tr>`
                    ).join('');

                    totalPriceDisplay.textContent = `₹${totalPrice.toFixed(2)}`;
                    totalPriceInput.value = totalPrice.toFixed(2);
                    productCounter.textContent = `Selected Products: ${selectedCount}`;

                    // Update discounted price dynamically
                    let discountPercentage = parseFloat(discountSelect.value) || 0;
                    discountedPriceText.textContent =
                        `Discounted Price: ₹${(totalPrice - totalPrice * (discountPercentage / 100)).toFixed(2)}`;
                });
            });

            // Update discounted price when the discount is changed
            discountSelect.addEventListener('change', function() {
                let totalPrice = parseFloat(totalPriceInput.value);
                let discountPercentage = parseFloat(discountSelect.value) || 0;
                discountedPriceText.textContent =
                    `Discounted Price: ₹${(totalPrice - totalPrice * (discountPercentage / 100)).toFixed(2)}`;
            });

            // Apply discount
            applyDiscount.addEventListener('click', function() {
                let discountedPrice = parseFloat(discountedPriceText.textContent.replace(
                    'Discounted Price: ₹', ''));
                discountPriceInput.value = discountedPrice.toFixed(2);
                productModal.classList.add('hidden');
            });

            // Toggle dropdown visibility
            dropdownToggle.addEventListener('click', function() {
                dropdownMenu.classList.toggle('hidden');
                dropdownIcon.innerHTML = dropdownMenu.classList.contains('hidden') ?
                    '<i class="fas fa-chevron-down"></i>' :
                    '<i class="fas fa-chevron-up"></i>';
            });

            // Ensure product selection meets min/max criteria
            productCheckboxes.forEach(checkbox => {
                checkbox.addEventListener('change', function() {
                    let selectedCount = [...productCheckboxes].filter(checkbox => checkbox.checked)
                        .length;
                    if (selectedCount < minSelection) {
                        productCounter.textContent =
                            `Selected Products: ${selectedCount} (Minimum 2 products required)`;
                        productCounter.classList.add('text-red-500');
                    } else if (selectedCount > maxSelection) {
                        productCounter.textContent =
                            `Selected Products: ${maxSelection} (Maximum 6 products allowed)`;
                        productCounter.classList.add('text-red-500');
                        checkbox.checked = false;
                    } else {
                        productCounter.textContent = `Selected Products: ${selectedCount}`;
                        productCounter.classList.remove('text-red-500');
                    }
                });
            });

            // Ensure discount price doesn't exceed total price
            discountPriceInput.addEventListener('input', function() {
                let discountPrice = parseFloat(discountPriceInput.value) || 0;
                let totalPrice = parseFloat(totalPriceInput.value);
                if (discountPrice > totalPrice) discountPriceInput.value = totalPrice.toFixed(2);
            });

            // Image preview functionality
            fileInput.addEventListener('change', function(event) {
                const file = event.target.files[0];
                if (file && file.type.startsWith('image/')) {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        imagePreview.src = e.target.result;
                        imagePreview.classList.remove('hidden');
                        imagePreviewContainer.classList.remove('hidden');
                    };
                    reader.readAsDataURL(file);
                } else {
                    imagePreview.classList.add('hidden');
                    imagePreviewContainer.classList.add('hidden');
                }
            });

            // Set the initial character count
            charCount.textContent = description.value.length;

            // Update character count on input event
            description.addEventListener('input', function() {
                charCount.textContent = this.value.length;
            });
        });
    </script>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Rudresh/address-laravel-auth/resources/views/combos/edit.blade.php ENDPATH**/ ?>