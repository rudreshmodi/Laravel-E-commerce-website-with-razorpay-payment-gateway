@extends('layouts.app')

@section('content')
    <div class="container mx-auto top-0">
        <!-- Breadcrumb Navigation -->
        <div class="flex px-5 py-3 text-gray-700 border border-gray-200 rounded-lg bg-gray-50 dark:bg-gray-800 dark:border-gray-700"
            aria-label="Breadcrumb">
            <ol class="inline-flex items-center space-x-1 md:space-x-2 rtl:space-x-reverse flex-1">
                <!-- Home Breadcrumb -->
                <li class="inline-flex items-center">
                    <a href="{{ route('dashboard') }}"
                        class="inline-flex items-center text-sm font-medium text-gray-700 hover:text-blue-600 dark:text-gray-400 dark:hover:text-white">
                        <svg class="w-3 h-3 me-2.5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor"
                            viewBox="0 0 20 20">
                            <path
                                d="m19.707 9.293-2-2-7-7a1 1 0 0 0-1.414 0l-7 7-2 2a1 1 0 0 0 1.414 1.414L2 10.414V18a2 2 0 0 0 2 2h3a1 1 0 0 0 1-1v-4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v4a1 1 0 0 0 1 1h3a2 2 0 0 0 2-2v-7.586l.293.293a1 1 0 0 0 1.414-1.414Z" />
                        </svg>
                        Home
                    </a>
                </li>

                <!-- Users Breadcrumb -->
                <li>
                    <div class="flex items-center">
                        <svg class="rtl:rotate-180 block w-3 h-3 mx-1 text-gray-400" aria-hidden="true"
                            xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="m1 9 4-4-4-4" />
                        </svg>
                        <a href="{{ route('user_details.index') }}"
                            class="ms-1 text-sm font-medium text-gray-700 hover:text-blue-600 md:ms-2 dark:text-gray-400 dark:hover:text-white">Users</a>
                    </div>
                </li>
            </ol>
        </div>

        <!-- Action Buttons: Add New User -->
        <div class="flex justify-between items-center mb-4 mt-5">
            <form action="{{ route('user_details.index') }}" method="GET" class="flex items-center space-x-3">
                <input type="text" name="search" placeholder="Search by name or email..."
                    value="{{ request()->search }}"
                    class="px-4 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-400">
                <button type="submit"
                    class="bg-blue-600 text-white px-4 py-2 rounded-full hover:bg-blue-700 transition duration-300 text-sm">
                    Search
                </button>
            </form>

            <a href="{{ route('user_details.create') }}"
                class="bg-indigo-900 text-white py-2 px-6 rounded-full shadow-md hover:bg-indigo-600 focus:outline-none focus:ring-2 focus:ring-indigo-400 transition duration-300 flex items-center text-sm">
                <i class="fas fa-plus-circle mr-2"></i> Create New User
            </a>
        </div>

        <!-- Users Table -->
        <div class="overflow-x-auto bg-white shadow-md rounded-lg">
            <table class="min-w-full table-auto border-separate border border-gray-200 rounded-lg">
                <thead class="bg-gray-100 text-gray-600">
                    <tr>
                        <th class="px-6 py-3 text-center text-sm font-bold">#</th>
                        <th class="px-6 py-3 text-center text-sm font-bold">Name</th>
                        <th class="px-6 py-3 text-center text-sm font-bold">Email</th>
                        <th class="px-6 py-3 text-center text-sm font-bold">Phone Number</th>
                        <th class="px-6 py-3 text-center text-sm font-bold">Role</th>
                        <th class="px-6 py-3 text-center text-sm font-bold">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200">
                    @foreach ($users as $user)
                        <tr class="hover:bg-gray-50 text-center">
                            <td class="px-6 py-4 text-sm text-gray-800">{{ $user->id }}</td>
                            <td class="px-6 py-4 text-sm text-gray-800">{{ $user->name }}</td>
                            <td class="px-6 py-4 text-sm text-gray-800">{{ $user->email }}</td>
                            <td class="px-6 py-4 text-sm text-gray-800">{{ $user->mobile_number }}</td>

                            <!-- Role Column with Toggle -->
                            <td class="px-6 py-4 text-sm text-center">
                                <span
                                    class="role-toggle-btn px-4 py-2 rounded-md transition duration-300
                                    {{ $user->role === 'admin' ? 'bg-green-500 text-white' : 'bg-blue-500 text-white' }}"
                                    data-user-id="{{ $user->id }}" data-current-role="{{ $user->role }}">
                                    {{ $user->role === 'admin' ? 'Admin' : 'User' }}
                                </span>
                            </td>

                            <!-- Actions Column -->
                            <td class="px-6 py-4 text-sm text-center">
                                <div class="flex justify-center space-x-4">
                                    <a href="{{ route('user_details.show', $user->id) }}"
                                        class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition duration-300 text-sm">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="{{ route('user_details.edit', $user->id) }}"
                                        class="bg-yellow-500 text-white px-4 py-2 rounded hover:bg-yellow-600 transition duration-300 text-sm">
                                        <i class="fas fa-edit"></i>
                                    </a>

                                    <!-- Delete Form -->
                                    <button onclick="confirmDelete({{ $user->id }})"
                                        class="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600 transition duration-300 text-sm">
                                        <i class="fas fa-trash-alt"></i>
                                    </button>
                                    <form id="delete-form-{{ $user->id }}"
                                        action="{{ route('user_details.destroy', $user->id) }}" method="POST"
                                        style="display:none;">
                                        @csrf
                                        @method('DELETE')
                                    </form>

                                    @if ($user->trashed())
                                        <form action="{{ route('user_details.restore', $user->id) }}" method="POST"
                                            style="display: inline;">
                                            @csrf
                                            <button type="submit"
                                                class="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 transition duration-300 text-sm">
                                                Restore
                                            </button>
                                        </form>
                                    @endif
                                </div>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>

        <!-- Confirmation Modal -->
        <div id="confirmationModal"
            class="fixed inset-0 z-50 hidden bg-gray-800 bg-opacity-50 flex justify-center items-center">
            <div class="bg-white p-6 rounded-md shadow-lg w-1/3">
                <h3 class="text-lg font-semibold text-gray-700">Are you sure you want to change the role of this user?</h3>
                <div class="flex justify-end mt-4">
                    <button onclick="cancelRoleChange()" class="bg-gray-500 text-white px-4 py-2 rounded-md mr-2">
                        Cancel
                    </button>
                    <button id="confirmRoleChangeBtn" class="bg-blue-500 text-white px-4 py-2 rounded-md">
                        Confirm
                    </button>
                </div>
            </div>
        </div>

        <!-- JavaScript to handle Role Toggle and Delete Confirmation -->
        <script>
            let userIdToChangeRole = null;
            let currentRoleToChange = null;

            // Handle role toggle
            const roleButtons = document.querySelectorAll('.role-toggle-btn');

            roleButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const userId = button.getAttribute('data-user-id');
                    const currentRole = button.getAttribute('data-current-role');
                    const newRole = currentRole === 'admin' ? 'user' : 'admin';
                    const newClass = newRole === 'admin' ? 'bg-green-500 text-white' : 'bg-blue-500 text-white';

                    userIdToChangeRole = userId;
                    currentRoleToChange = currentRole;

                    // Show confirmation modal
                    document.getElementById('confirmationModal').classList.remove('hidden');
                });
            });

            // Cancel Role Change
            function cancelRoleChange() {
                userIdToChangeRole = null;
                document.getElementById('confirmationModal').classList.add('hidden');
            }

            // Confirm Role Change
            document.getElementById('confirmRoleChangeBtn').addEventListener('click', function() {
                if (userIdToChangeRole !== null) {
                    const newRole = currentRoleToChange === 'admin' ? 'user' : 'admin';
                    const newClass = newRole === 'admin' ? 'bg-green-500 text-white' : 'bg-blue-500 text-white';

                    fetch(`/users/${userIdToChangeRole}/toggle-role`, {
                            method: 'PATCH',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')
                                    .getAttribute('content')
                            },
                            body: JSON.stringify({
                                role: newRole
                            })
                        }).then(response => response.json())
                        .then(data => {
                            // Update UI
                            const button = document.querySelector(`[data-user-id="${userIdToChangeRole}"]`);
                            button.textContent = newRole.charAt(0).toUpperCase() + newRole.slice(1);
                            button.className = `role-toggle-btn px-4 py-2 rounded-md transition duration-300 ${newClass}`;
                            button.setAttribute('data-current-role', newRole);

                            // Close modal
                            cancelRoleChange();
                        })
                        .catch(error => console.error('Error:', error));
                }
            });

            // Confirm delete
            function confirmDelete(userId) {
                userIdToDelete = userId;
                document.getElementById('confirmationModal').classList.remove('hidden');
            }

            function cancelDelete() {
                userIdToDelete = null;
                document.getElementById('confirmationModal').classList.add('hidden');
            }

            document.getElementById('confirmDeleteBtn').addEventListener('click', function() {
                if (userIdToDelete !== null) {
                    document.getElementById(`delete-form-${userIdToDelete}`).submit();
                }
            });
        </script>

        <!-- Pagination -->
        <div class="mt-4">
            {{ $users->links() }} <!-- Pagination Links -->
        </div>
    </div>

    <!-- Success and Error Toasts -->
    @if (session('success'))
        <div id="successToast"
            class="fixed top-10 right-10 z-50 bg-green-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3 text-sm">
            <i class="fas fa-check-circle text-white text-2xl"></i>
            <span>{{ session('success') }}</span>
        </div>
        <script>
            setTimeout(() => {
                document.querySelector('#successToast').style.display = 'none';
            }, 4000);
        </script>
    @endif

    @if (session('error'))
        <div id="errorToast"
            class="fixed top-10 right-10 z-50 bg-red-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3 text-sm">
            <i class="fas fa-times-circle text-white text-2xl"></i>
            <span>{{ session('error') }}</span>
        </div>
        <script>
            setTimeout(() => {
                document.querySelector('#errorToast').style.display = 'none';
            }, 4000);
        </script>
    @endif
@endsection
