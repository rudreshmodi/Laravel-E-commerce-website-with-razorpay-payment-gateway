@extends('layouts.user')

@section('title', 'E-commerce Shopping | Combo Details')

@section('content')
<!-- Back Icon -->
<section class="py-8 bg-gradient-to-r from-blue-50 to-gray-100 shadow-md">
    <!-- Breadcrumb Navigation -->
    <nav class="w-full bg-white shadow-md py-4 -mt-9 mb-6 rounded-lg px-6 md:px-12" aria-label="Breadcrumb">
        <ol class="inline-flex items-center space-x-1 md:space-x-2 rtl:space-x-reverse">
            <!-- Home Breadcrumb -->
            <li class="inline-flex items-center">
                <a href="{{ url('/') }}"
                    class="inline-flex items-center text-sm font-medium text-gray-700 hover:text-primary-600 dark:text-gray-400 dark:hover:text-white">
                    <svg class="me-2.5 h-3 w-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                        fill="currentColor" viewBox="0 0 20 20">
                        <path
                            d="m19.707 9.293-2-2-7-7a1 1 0 0 0-1.414 0l-7 7-2 2a1 1 0 0 0 1.414 1.414L2 10.414V18a2 2 0 0 0 2 2h3a1 1 0 0 0 1-1v-4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v4a1 1 0 0 0 1 1h3a2 2 0 0 0 2-2v-7.586l.293.293a1 1 0 0 0 1.414-1.414Z" />
                    </svg>
                    Home
                </a>
            </li>
            <!-- Combos Breadcrumb -->
            <li>
                <div class="flex items-center">
                    <svg class="h-5 w-5 text-gray-400 rtl:rotate-180" aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="m9 5 7 7-7 7" />
                    </svg>
                    <a href="{{ route('shop.index') }}"
                        class="ms-1 text-sm font-medium text-gray-700 hover:text-primary-600 dark:text-gray-400 dark:hover:text-white md:ms-2">Combos</a>
                </div>
            </li>
            <!-- Current Combo Breadcrumb -->
            <li aria-current="page">
                <div class="flex items-center">
                    <svg class="h-5 w-5 text-gray-400 rtl:rotate-180" aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="m9 5 7 7-7 7" />
                    </svg>
                    <span class="ms-1 text-sm font-medium text-gray-500 dark:text-gray-400 md:ms-2">{{ $combo->name
                        }}</span>
                </div>
            </li>
        </ol>
    </nav>

    <div class="container mt-8 mx-auto py-2 px-4" style="height: 490px;">
        <div class="flex flex-col lg:flex-row lg:gap-24">

            <!-- Combo Image Section -->
            <div class="lg:w-5/12 flex justify-center lg:flex-col lg:items-center">
                <div class="relative flex flex-col lg:flex-row items-start">
                    @if ($combo->image)
                    <!-- Combo Image -->
                    <img src="{{ asset('storage/' . $combo->image) }}" alt="{{ $combo->name }}"
                        class="w-full h-96 object-contain rounded-lg shadow-xl" />
                    @else
                    <img src="{{ asset('images/placeholder.png') }}" alt="{{ $combo->name }}"
                        class="w-full h-auto object-cover rounded-md" />
                    @endif
                </div>
            </div>

            <!-- Combo Info Section -->
            <div class="lg:w-7/12 flex flex-col space-y-6">
                <p class="text-xl font-semibold text-gray-800 hover:text-blue-600 transition-colors duration-300">
                    {{ $combo->name }}
                </p>
                <p class="text-sm text-gray-500">Category: <span class="text-gray-700 font-semibold">{{
                        $combo->category->name }}</span></p>
                <p class="text-xs text-gray-600 mt-4 leading-relaxed">{{ $combo->description }}</p>

                <p class="text-xl font-bold text-gray-800">₹{{ number_format($combo->total_price, 2) }}</p>

                <!-- Add to Cart and Wishlist Buttons -->
                <div class="mt-6 grid grid-cols-1 gap-4">
                    <div class="flex items-center justify-between border p-4 rounded-lg shadow-md bg-white">
                        <div class="flex space-x-4 w-full">
                            <!-- Add to Wishlist Button -->
                            @php
                            $isInWishlist = in_array($combo->id, session('wishlist', []));
                            @endphp
                            <form
                                action="{{ $isInWishlist ? route('wishlist.remove', $combo) : route('wishlist.add', $combo) }}"
                                method="POST" class="flex-1">
                                @csrf
                                @if ($isInWishlist)
                                @method('DELETE')
                                @endif
                                <button type="submit"
                                    class="w-full flex items-center justify-center bg-transparent border-2 px-3 py-2 rounded-md transition-all duration-300 {{ $isInWishlist ? 'text-red-500 border-red-500' : 'text-gray-700 border-gray-300' }}">
                                    <i
                                        class="bx {{ $isInWishlist ? 'bxs-heart text-red-500' : 'bx-heart text-gray-300' }} text-2xl mr-2"></i>
                                    <span class="hidden sm:inline">{{ $isInWishlist ? 'Unsave' : 'Save' }}</span>
                                </button>
                            </form>

                            <!-- Add to Cart / Quantity Controls -->
                            @php
                            $isInCart = isset($cartItems[$combo->id]);
                            @endphp

                            @if ($isInCart)
                            <!-- Quantity Controls for items in the cart -->
                            <div class="flex items-center space-x-4">
                                <form action="{{ route('cart.updateQuantity', $combo) }}" method="POST"
                                    class="inline-flex items-center space-x-3">
                                    @csrf
                                    @method('PATCH')
                                    <span class="bg-gray-100 rounded-md text-lg font-semibold p-3 w-12 text-center">{{
                                        $cartItems[$combo->id]['quantity'] }}</span>
                                    <div class="flex space-x-2">
                                        <!-- Minus Button -->
                                        <button type="submit" name="quantity"
                                            value="{{ $cartItems[$combo->id]['quantity'] - 1 }}"
                                            class="bg-gray-300 text-gray-700 hover:bg-gray-400 px-4 py-2 rounded-md transition duration-300 {{ $cartItems[$combo->id]['quantity'] <= 1 ? 'opacity-50 cursor-not-allowed' : '' }}"
                                            {{ $cartItems[$combo->id]['quantity'] <= 1 ? 'disabled' : '' }}>
                                                <i class="fas fa-minus"></i>
                                        </button>
                                        <!-- Plus Button -->
                                        <button type="submit" name="quantity"
                                            value="{{ $cartItems[$combo->id]['quantity'] + 1 }}"
                                            class="bg-gray-300 text-gray-700 hover:bg-gray-400 px-4 py-2 rounded-md transition duration-300">
                                            <i class="fas fa-plus"></i>
                                        </button>
                                    </div>
                                </form>
                                <!-- Remove Button -->
                                <form action="{{ route('cart.remove', $combo) }}" method="POST" class="inline">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit"
                                        class="text-red-500 border-2 border-red-500 hover:bg-red-500 hover:text-white py-2 px-4 rounded-md text-center flex items-center justify-center space-x-2 transition-all duration-300">
                                        <i class="fas fa-trash-alt text-lg"></i>
                                        <span class="hidden sm:inline">Remove</span>
                                    </button>
                                </form>
                            </div>
                            @else
                            <!-- Add to Cart Button -->
                            <form action="{{ route('cart.add', $combo) }}" method="POST" class="w-full">
                                @csrf
                                <button type="submit"
                                    class="flex items-center justify-center bg-blue-500 text-white p-3 rounded-md font-medium hover:bg-blue-600 transition w-full">
                                    <i class="fas fa-cart-plus mr-2"></i>
                                    <span class="hidden sm:inline">Add to Cart</span>
                                </button>
                            </form>
                            @endif
                        </div>
                    </div>
                </div>

                <!-- Combo Category & Tags -->
                <div class="mt-6 text-sm text-gray-500">
                    <p><strong>Category:</strong> <span class="text-gray-700 font-semibold">{{ $combo->category->name
                            }}</span></p>
                </div>

                <!-- Additional Combo Information -->
                <div class="mt-6 text-sm text-gray-500 space-y-2">
                    <p><i class="fas fa-info-circle text-blue-500"></i> Secure payment processing & fast delivery.</p>
                    <p><i class="fas fa-shield-alt text-blue-500"></i> 7-days return policy on all items.</p>
                </div>
            </div>

        </div>
    </div>
</section>
@endsection
