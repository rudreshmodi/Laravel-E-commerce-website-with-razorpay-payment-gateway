@extends('layouts.app')

@section('content')
    <div class="container mx-auto mt-0">
        <!-- Breadcrumb -->
        <div class="flex px-3 py-4 text-gray-700 border border-gray-200 rounded-lg bg-gray-50 dark:bg-gray-800 dark:border-gray-700"
            aria-label="Breadcrumb">
            <ol class="inline-flex items-center space-x-1 md:space-x-2 rtl:space-x-reverse">
                <!-- Home Breadcrumb -->
                <li class="inline-flex items-center">
                    <a href="{{ route('dashboard') }}"
                        class="inline-flex items-center text-sm font-medium text-gray-700 hover:text-blue-600 dark:text-gray-400 dark:hover:text-white">
                        <svg class="w-3 h-3 me-2.5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor"
                            viewBox="0 0 20 20">
                            <path
                                d="m19.707 9.293-2-2-7-7a1 1 0 0 0-1.414 0l-7 7-2 2a1 1 0 0 0 1.414 1.414L2 10.414V18a2 2 0 0 0 2 2h3a1 1 0 0 0 1-1v-4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v4a1 1 0 0 0 1 1h3a2 2 0 0 0 2-2v-7.586l.293.293a1 1 0 0 0 1.414-1.414Z" />
                        </svg>
                        Home
                    </a>
                </li>

                <!-- Separator -->
                <li>
                    <div class="flex items-center">
                        <svg class="rtl:rotate-180 block w-3 h-3 mx-1 text-gray-400" aria-hidden="true"
                            xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="m1 9 4-4-4-4" />
                        </svg>
                        <a href="{{ route('products.index') }}"
                            class="ms-1 text-sm font-medium text-gray-700 hover:text-blue-600 md:ms-2 dark:text-gray-400 dark:hover:text-white">Products</a>
                    </div>
                </li>

                <!-- Current Page -->
                <li aria-current="page">
                    <div class="flex items-center">
                        <svg class="rtl:rotate-180 w-3 h-3 mx-1 text-gray-400" aria-hidden="true"
                            xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="m1 9 4-4-4-4" />
                        </svg>
                        <span class="ms-1 text-sm font-medium text-gray-500 md:ms-2 dark:text-gray-400">Deleted
                            Products</span>
                    </div>
                </li>
            </ol>

            <!-- Button to Go Back to Categories (Aligned to the Right) -->
            <div class="ml-auto">
                <a href="{{ route('products.index') }}"
                    class="bg-indigo-400 text-white px-4 py-2 rounded-full shadow-md hover:bg-indigo-600 focus:outline-none focus:ring-2 focus:ring-yellow-400 transition duration-300">
                    Back to Products
                </a>
            </div>
        </div>

        <!-- Table to display deleted products -->
        <div class="overflow-x-auto bg-white rounded-lg shadow-xl mt-6">
            <table class="min-w-full table-auto border-separate border border-gray-200 rounded-lg">
                <thead class="bg-gray-100 text-gray-600">
                    <tr>
                        <th class="px-6 py-3 text-center text-md font-bold">Product Name</th>

                        <th class="px-6 py-3 text-center text-md font-bold">Subcategory</th>
                        <th class="px-6 py-3 text-center text-md font-bold">Category</th>
                        <th class="px-6 py-3 text-center text-md font-bold">Price</th>
                        <th class="px-6 py-3 text-center text-md font-bold">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200">
                    @foreach ($deletedProducts as $product)
                        <tr class="hover:bg-gray-50 transition-colors text-center duration-200">
                            <td class="px-6 py-4 text-sm text-gray-800">{{ $product->name }}</td>
                            <td class="px-6 py-4 text-sm text-gray-800">
                                {{ $product->subcategory->name ?? 'No Subcategory' }}</td>
                            <td class="px-6 py-4 text-sm text-gray-800">{{ $product->category->name ?? 'No category' }}</td>

                            <td class="px-6 py-4 text-sm text-gray-800">${{ number_format($product->price, 2) }}</td>
                            <td class="px-6 py-4 text-sm text-center">
                                <div class="flex justify-center space-x-2">
                                    <!-- Restore Button -->
                                    <button type="button"
                                        class="bg-yellow-500 text-white px-4 py-2 rounded hover:bg-yellow-600 transition duration-300 flex items-center space-x-2"
                                        onclick="openRestoreModal({{ $product->id }})">
                                        <i class="fas fa-undo"></i><span>Restore</span>
                                    </button>

                                    <!-- Delete Permanently Button -->
                                    <button type="button"
                                        class="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600 transition duration-300 flex items-center space-x-2"
                                        onclick="openDeleteModal({{ $product->id }})">
                                        <i class="fas fa-trash-alt"></i> <span>Delete Permanently</span>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>

        <!-- No Deleted Products Found Message -->
        @if ($deletedProducts->isEmpty())
            <div class="mt-8 text-center text-gray-500">
                <p>No deleted products found.</p>
            </div>
        @endif
    </div>

    <!-- Restore Confirmation Modal -->
    <div id="restoreModal" class="fixed inset-0 flex items-center justify-center bg-gray-800 bg-opacity-50 hidden">
        <div class="bg-white p-6 rounded-xl shadow-xl max-w-lg w-full" style=" margin:auto; width:1000px;">
            <div class="text-center mb-4">
                <div class="flex items-center justify-center mb-4">
                    <i class="fas fa-undo text-yellow-500 text-4xl mr-3"></i>
                    <h2 class="text-2xl font-semibold text-gray-800">Are you sure you want to restore this product?</h2>
                </div>
            </div>

            <div class="flex justify-end gap-2">
                <button onclick="closeRestoreModal()"
                    class="bg-gray-300 text-gray-700 px-6 py-3 rounded-lg shadow-md hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-300 transition duration-300 w-32 flex items-center justify-center space-x-2">
                    <i class="fas fa-times-circle"></i>
                    <span>Cancel</span>
                </button>
                <form id="restoreForm" method="POST" class="inline w-32">
                    @csrf
                    <button type="submit"
                        class="bg-yellow-500 text-white px-6 py-3 rounded-lg shadow-md hover:bg-yellow-600 focus:outline-none focus:ring-2 focus:ring-yellow-400 transition duration-300 w-full flex items-center justify-center space-x-2">
                        <i class="fas fa-check-circle"></i>
                        <span>Restore</span>
                    </button>
                </form>
            </div>
        </div>
    </div>

    <!-- Delete Permanently Confirmation Modal (Step 1) -->
    <div id="deleteModal" class="fixed inset-0 flex items-center justify-center bg-gray-800 bg-opacity-50 hidden">
        <div class="bg-white p-4 rounded-xl shadow-xl max-w-lg w-full" style=" margin:auto; width:1000px;">
            <div class="text-center mb-4">
                <div class="flex items-center justify-center mb-4">
                    <i class="fas fa-trash-alt text-red-500 text-4xl mr-3"></i>
                    <h2 class="text-2xl font-semibold text-gray-800">Are you sure you want to delete this product
                        permanently?</h2>
                </div>

            </div>
            <p class="text-gray-600 text-lg text-center mb-6">This action is irreversible, and the product will be
                permanently deleted from the system.</p>
            <div class="flex justify-end gap-2">
                <button onclick="closeDeleteModal()"
                    class="bg-gray-300 text-gray-700 px-6 py-3 rounded-lg shadow-md hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-300 transition duration-300 w-32 flex items-center justify-center space-x-2">
                    <i class="fas fa-times-circle"></i>
                    <span>Cancel</span>
                </button>
                <button onclick="showSecondDeleteStep()"
                    class="bg-red-500 text-white px-6 py-3 rounded-lg shadow-md hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-red-400 transition duration-300 w-32 flex items-center justify-center space-x-2">
                    <i class="fas fa-check-circle"></i>
                    <span>Confirm</span>
                </button>
            </div>
        </div>
    </div>

    <!-- Delete Permanently Confirmation Modal (Step 2) -->
    <div id="secondDeleteModal" class="fixed inset-0 flex items-center justify-center bg-gray-800 bg-opacity-50 hidden">
        <div class="bg-white p-4 rounded-xl shadow-xl max-w-lg w-full">
            <div class="text-center mb-4">
                <i class="fas fa-trash-alt text-red-500 text-4xl mb-3"></i>
                <h2 class="text-2xl font-semibold text-gray-800">Are you really sure?</h2>
            </div>
            <p class="text-gray-600 text-lg text-center mb-6">This action cannot be undone. The product will be permanently
                removed from your database.</p>
            <div class="flex justify-end gap-2">
                <button onclick="closeSecondDeleteModal()"
                    class="bg-gray-300 text-gray-700 px-6 py-3 rounded-lg shadow-md hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-300 transition duration-300 w-32 flex items-center justify-center space-x-2">
                    <i class="fas fa-times-circle"></i>
                    <span>Cancel</span>
                </button>
                <form id="deleteForm" method="POST" class="inline w-32">
                    @csrf
                    @method('DELETE')
                    <button type="submit"
                        class="bg-red-500 text-white px-6 py-3 rounded-lg shadow-md hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-red-400 transition duration-300 w-full flex items-center justify-center space-x-2">
                        <i class="fas fa-trash-alt"></i>
                        <span>Delete Permanently</span>
                    </button>
                </form>
            </div>
        </div>
    </div>

    @if (session('success'))
        <div id="successToast"
            class="fixed top-10 right-10 z-50 bg-green-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
            <!-- Success Icon -->
            <i class="fas fa-check-circle text-white text-2xl"></i>
            <!-- Success Message -->
            <span>{{ session('success') }}</span>
        </div>

        <script>
            setTimeout(() => {
                document.querySelector('#successToast').style.display = 'none';
            }, 4000);
        </script>
    @endif

    <!-- Error Toast -->
    @if (session('error'))
        <div id="errorToast"
            class="fixed top-10 right-10 z-50 bg-red-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
            <!-- Error Icon -->
            <i class="fas fa-times-circle text-white text-2xl"></i>
            <!-- Error Message -->
            <span>{{ session('error') }}</span>
        </div>

        <script>
            setTimeout(() => {
                document.querySelector('#errorToast').style.display = 'none';
            }, 4000);
        </script>
    @endif

    <script>
        function openRestoreModal(productId) {
            // Dynamically set the form action for restoring the product
            const restoreUrl = '{{ route('deleted-products.restore', ':id') }}'.replace(':id', productId);
            document.getElementById('restoreForm').action = restoreUrl;

            // Show the restore modal
            document.getElementById('restoreModal').classList.remove('hidden');
        }

        function closeRestoreModal() {
            // Close the restore modal
            document.getElementById('restoreModal').classList.add('hidden');
        }

        function openDeleteModal(productId) {
            // Dynamically set the form action for force deleting the product
            const deleteUrl = '{{ route('deleted-products.force-delete', ':id') }}'.replace(':id', productId);
            document.getElementById('deleteForm').action = deleteUrl;

            // Show the delete modal
            document.getElementById('deleteModal').classList.remove('hidden');
        }

        function closeDeleteModal() {
            // Close the delete modal
            document.getElementById('deleteModal').classList.add('hidden');
        }

        function showSecondDeleteStep() {
            // Hide the first delete modal and show the second confirmation step
            document.getElementById('deleteModal').classList.add('hidden');
            document.getElementById('secondDeleteModal').classList.remove('hidden');
        }

        function closeSecondDeleteModal() {
            // Close the second delete confirmation modal
            document.getElementById('secondDeleteModal').classList.add('hidden');
        }
    </script>
@endsection
