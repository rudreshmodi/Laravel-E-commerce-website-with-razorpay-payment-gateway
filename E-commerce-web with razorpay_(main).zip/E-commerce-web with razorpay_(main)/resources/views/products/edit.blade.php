@extends('layouts.app')

@section('title', 'Edit Product')

@section('content')
    <div class="container mx-auto mt-6 px-4">

        <!-- Breadcrumb -->
        <div class="flex px-5 py-3 text-gray-700 border border-gray-200 rounded-lg bg-gray-50 dark:bg-gray-800 dark:border-gray-700"
            aria-label="Breadcrumb">
            <ol class="inline-flex items-center space-x-1 md:space-x-2 rtl:space-x-reverse">
                <!-- Home Breadcrumb -->
                <li class="inline-flex items-center">
                    <a href="{{ route('dashboard') }}"
                        class="inline-flex items-center text-sm font-medium text-gray-700 hover:text-blue-600 dark:text-gray-400 dark:hover:text-white">
                        <svg class="w-3 h-3 me-2.5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor"
                            viewBox="0 0 20 20">
                            <path
                                d="m19.707 9.293-2-2-7-7a1 1 0 0 0-1.414 0l-7 7-2 2a1 1 0 0 0 1.414 1.414L2 10.414V18a2 2 0 0 0 2 2h3a1 1 0 0 0 1-1v-4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v4a1 1 0 0 0 1 1h3a2 2 0 0 0 2-2v-7.586l.293.293a1 1 0 0 0 1.414-1.414Z" />
                        </svg>
                        Home
                    </a>
                </li>

                <!-- Separator -->
                <li>
                    <div class="flex items-center">
                        <svg class="rtl:rotate-180 block w-3 h-3 mx-1 text-gray-400" aria-hidden="true"
                            xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="m1 9 4-4-4-4" />
                        </svg>
                        <a href="{{ route('products.index') }}"
                            class="ms-1 text-sm font-medium text-gray-700 hover:text-blue-600 md:ms-2 dark:text-gray-400 dark:hover:text-white">Products</a>
                    </div>
                </li>

                <!-- Separator -->
                <li>
                    <div class="flex items-center">
                        <svg class="rtl:rotate-180 block w-3 h-3 mx-1 text-gray-400" aria-hidden="true"
                            xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="m1 9 4-4-4-4" />
                        </svg>
                        <span class="ms-1 text-sm font-medium text-gray-500 md:ms-2 dark:text-gray-400">Edit</span>
                    </div>
                </li>
            </ol>
        </div>

        <!-- Full-Screen Width Card Container for the Form -->
        <div class="w-full bg-white p-8 rounded-lg shadow-xl">
            <div class="flex justify-between items-center mb-6">
                <h2 class="text-3xl font-semibold text-gray-800 flex items-center">
                    <i class="fas fa-edit mr-2"></i> Edit Product
                </h2>
            </div>

            <!-- Inline Alerts for Success and Error Messages -->
            @if (session('success'))
                <div class="mb-6 p-4 bg-green-100 text-green-800 border border-green-400 rounded-md">
                    <i class="fas fa-check-circle"></i> {{ session('success') }}
                </div>
            @elseif (session('error'))
                <div class="mb-6 p-4 bg-red-100 text-red-800 border border-red-400 rounded-md">
                    <i class="fas fa-exclamation-circle"></i> {{ session('error') }}
                </div>
            @endif

            <!-- Form to Edit Product -->
            <form action="{{ route('products.update', $product->id) }}" method="POST" enctype="multipart/form-data"
                class="space-y-6">
                @csrf
                @method('PUT')

                <!-- Flex container for category and subcategory -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    <div>
                        <label for="category_id" class="block text-sm font-medium text-gray-700">
                            Category <span class="text-red-500">*</span>
                        </label>
                        <select name="category_id" id="category_id"
                            class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                            <option value="">Select Category</option>
                            @foreach ($categories as $category)
                                <option value="{{ $category->id }}"
                                    {{ old('category_id', $product->category_id) == $category->id ? 'selected' : '' }}>
                                    {{ $category->name }}
                                </option>
                            @endforeach
                        </select>
                        @error('category_id')
                            <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                        @enderror
                    </div>

                    <div>
                        <label for="subcategory_id" class="block text-sm font-medium text-gray-700">
                            Subcategory <span class="text-red-500">*</span>
                        </label>
                        <select name="subcategory_id" id="subcategory_id"
                            class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                            <option value="">Select Subcategory</option>
                            @foreach ($subcategories as $subcategory)
                                <option value="{{ $subcategory->id }}"
                                    {{ old('subcategory_id', $product->subcategory_id) == $subcategory->id ? 'selected' : '' }}>
                                    {{ $subcategory->name }}
                                </option>
                            @endforeach
                        </select>
                        @error('subcategory_id')
                            <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                        @enderror
                    </div>

                </div>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">

                    <!-- Product Name -->
                    <div>
                        <label for="name" class="block text-sm font-medium text-gray-700">
                            Product Name <span class="text-red-500">*</span>
                        </label>
                        <div class="relative">
                            <input type="text" name="name" id="name" value="{{ old('name', $product->name) }}"
                                class="mt-1 block w-full px-4 py-2 pr-10 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                            <i class="fas fa-tag absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                        </div>
                        @error('name')
                            <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                        @enderror
                    </div>
                    <!-- Product Price -->
                    <div>
                        <label for="price" class="block text-sm font-medium text-gray-700">
                            Product Price <span class="text-red-500">*</span>
                        </label>
                        <div class="relative">
                            <input type="number" name="price" id="price" value="{{ old('price', $product->price) }}"
                                step="0.01" min="0"
                                class="mt-1 block w-full px-4 py-2 pr-10 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                            <i
                                class="fas fa-dollar-sign absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                        </div>
                        @error('price')
                            <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                        @enderror
                    </div>
                </div>

                <!-- Product Description (With Character Count) -->
                <div>
                    <label for="description" class="block text-sm font-medium text-gray-700">
                        Product Description <span class="text-red-500">*</span>
                    </label>
                    <div class="relative">
                        <textarea name="description" id="description" rows="4" maxlength="255" oninput="updateCharCount()"
                            class="mt-1 block w-full px-4 py-2 pr-10 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">{{ old('description', $product->description) }}</textarea>
                        <i class="fas fa-pencil-alt absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                    </div>
                    <div class="right-18 text-sm text-gray-500 mt-1">
                        <span id="charCount"
                            class="text-sm text-gray-500">{{ strlen(old('description', $product->description)) }}</span><span
                            class="text-sm text-gray-500"> / 255</span>
                    </div>
                    @error('description')
                        <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                    @enderror
                </div>



                <!-- Product Status -->
                <div>
                    <label for="status" class="block text-sm font-medium text-gray-700">
                        Product Status <span class="text-red-500">*</span>
                    </label>
                    <select name="status" id="status"
                        class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <option value="" disabled {{ old('status') ? '' : 'selected' }}>Please choose a status
                        </option>
                        <option value="active" {{ old('status', $product->status) == 'active' ? 'selected' : '' }}>
                            Active</option>
                        <option value="inactive" {{ old('status', $product->status) == 'inactive' ? 'selected' : '' }}>
                            Inactive</option>
                    </select>
                    @error('status')
                        <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                    @enderror
                </div>


                <!-- Product Image(s) (Optional) -->
                <div>
                    <label for="images" class="block text-sm font-medium text-gray-700">
                        Product Image(s) (Optional)
                    </label>
                    <!-- Multiple Image Upload Input -->
                    <input type="file" name="images[]" id="images" accept="image/*" multiple
                        class="mt-4 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                        onchange="previewImages()">
                    <p class="mt-2 text-sm text-gray-500">Current Images</p>

                    <!-- Display Current Product Images and New Image Previews -->
                    <div class="flex gap-6 mt-4 col-lg-12">
                        <!-- Existing Images -->
                        <div class="flex flex-wrap gap-4 col-lg-6">
                            @php
                                $images = explode(',', $product->images); // Convert the comma-separated string into an array
                            @endphp

                            @if (is_array($images) && count($images) > 0)
                                @foreach ($images as $image)
                                    <div class="w-16 h-16 overflow-hidden rounded-md">
                                        <img src="{{ asset('storage/' . $image) }}" class="w-full h-full object-cover"
                                            alt="Product Image">
                                    </div>
                                @endforeach
                            @else
                                <div class="w-16 h-16 bg-gray-300 flex justify-center items-center text-white rounded-md">
                                    <p class="text-sm">No Image</p>
                                </div>
                            @endif
                        </div>

                        <!-- New Image Preview Container -->
                        <div id="imagePreviewContainer" class="w-auto">
                            <p class="text-center bg-gray-600 rounded-md text-gray-200 py-8 px-2">New Image Previews</p>
                            <div id="newImagePreviews" class="flex gap-6"></div>
                        </div>
                    </div>
                </div>

                <!-- Inline Error Message Container for File Validation -->
                <div id="imageErrorMessages" class="mt-4 text-sm text-red-500"></div>

                @error('image')
                    <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                @enderror

                <!-- Submit and Cancel Buttons -->
                <div class="flex justify-end space-x-4 mt-6">
                    <a href="{{ route('products.index') }}"
                        class="bg-gray-300 text-gray-800 px-6 py-2 rounded hover:bg-gray-400 transition duration-300 flex items-center">
                        <i class="fas fa-times-circle mr-2"></i> Cancel
                    </a>
                    <button type="submit"
                        class="bg-blue-500 text-white px-6 py-2 rounded hover:bg-blue-600 transition duration-300 flex items-center">
                        <i class="fas fa-save mr-2"></i> Save Changes
                    </button>
                </div>
            </form>
        </div>

    </div>

    <!-- Success and Error Toasts -->
    @if (session('success'))
        <div id="successToast"
            class="fixed top-10 right-10 z-50 bg-green-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
            <i class="fas fa-check-circle text-white text-2xl"></i>
            <span>{{ session('success') }}</span>
        </div>

        <script>
            setTimeout(() => {
                document.querySelector('#successToast').style.display = 'none';
            }, 4000);
        </script>
    @endif

    @if (session('error'))
        <div id="errorToast"
            class="fixed top-10 right-10 z-50 bg-red-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
            <i class="fas fa-times-circle text-white text-2xl"></i>
            <span>{{ session('error') }}</span>
        </div>

        <script>
            setTimeout(() => {
                document.querySelector('#errorToast').style.display = 'none';
            }, 4000);
        </script>
    @endif

    <script>
        // Function to preview multiple images before upload
        function previewImages() {
            const fileInput = document.getElementById('images'); // The file input element
            const imagePreviewContainer = document.getElementById('newImagePreviews'); // Container for previews
            const errorMessagesContainer = document.getElementById('imageErrorMessages'); // Container for error messages

            // Clear any previous previews and error messages
            imagePreviewContainer.innerHTML = '';
            errorMessagesContainer.innerHTML = '';

            // If no files are selected, exit the function
            if (!fileInput.files.length) {
                return;
            }

            // Loop through selected files and create image previews
            Array.from(fileInput.files).forEach(file => {
                // Validate file size (max 10MB)
                if (file.size > 10 * 1024 * 1024) { // 10MB in bytes
                    const errorMessage = document.createElement('p');
                    errorMessage.textContent = 'Image size must be less than or equal to 10MB.';
                    errorMessagesContainer.appendChild(errorMessage);
                    return;
                }

                // Validate file type (only jpeg, png, jpg allowed)
                const validExtensions = ['image/jpeg', 'image/png', 'image/jpg', 'image/webp'];
                if (!validExtensions.includes(file.type)) {
                    const errorMessage = document.createElement('p');
                    errorMessage.textContent = 'Only image files (jpeg, png, jpg, webp) are allowed.';
                    errorMessagesContainer.appendChild(errorMessage);
                    return;
                }

                // Create a FileReader to preview the image
                const reader = new FileReader();
                reader.onload = function(event) {
                    const result = event.target.result; // Access the file result
                    const imgContainer = document.createElement('div');
                    imgContainer.classList.add('w-16', 'h-16');
                    const img = document.createElement('img');
                    img.src = result;
                    img.classList.add('w-full', 'h-full', 'object-cover', 'rounded-md');
                    imgContainer.appendChild(img);
                    imagePreviewContainer.appendChild(imgContainer); // Add image preview to container
                };
                reader.readAsDataURL(file); // Read the file as a Data URL for image preview
            });
        }

        // Character count update for the product description
        function updateCharCount() {
            const charCount = document.getElementById('charCount');
            const description = document.getElementById('description').value;
            charCount.textContent = description.length;
        }
    </script>
    <script>
        // When the category changes, make an AJAX call to get the subcategories
        document.getElementById('category_id').addEventListener('change', function() {
            const categoryId = this.value;
            const subcategoryDropdown = document.getElementById('subcategory_id');

            // Clear previous subcategory options
            subcategoryDropdown.innerHTML = '<option value="">Select Subcategory</option>';

            if (categoryId) {
                // Make an AJAX request to fetch subcategories based on the selected category
                fetch(`/get-subcategories/${categoryId}`)
                    .then(response => response.json())
                    .then(data => {
                        // Check if subcategories are available
                        if (data.length > 0) {
                            data.forEach(subcategory => {
                                const option = document.createElement('option');
                                option.value = subcategory.id;
                                option.textContent = subcategory.name;
                                subcategoryDropdown.appendChild(option);
                            });
                        } else {
                            // If no subcategories are available
                            const option = document.createElement('option');
                            option.value = '';
                            option.textContent = 'No subcategories available';
                            subcategoryDropdown.appendChild(option);
                        }
                    })
                    .catch(error => {
                        console.error('Error fetching subcategories:', error);
                    });
            }
        });

        // Character Counter
        function updateCharCount() {
            const description = document.getElementById('description');
            const charCount = document.getElementById('charCount');
            charCount.textContent = description.value.length + ' / 255';
        }

        // Image preview
        document.getElementById('images').addEventListener('change', function(event) {
            const files = event.target.files;
            const imagePreviews = document.getElementById('imagePreviews');
            imagePreviews.innerHTML = ''; // Clear previous previews

            // Loop through selected files and create image preview
            Array.from(files).forEach(file => {
                const reader = new FileReader();

                reader.onload = function(e) {
                    const img = document.createElement('img');
                    img.src = e.target.result;
                    img.classList.add('w-12', 'h-12', 'object-cover', 'rounded-md', 'cursor-pointer');
                    imagePreviews.appendChild(img);

                    // Add click event for zoom functionality
                    img.addEventListener('click', function() {
                        openZoomModal(e.target.result);
                    });
                };

                reader.readAsDataURL(file);
            });
        });

        // Zoom modal functionality
        function openZoomModal(imgSrc) {
            const zoomModal = document.getElementById('zoomModal');
            const zoomedImg = document.getElementById('zoomedImg');
            zoomedImg.src = imgSrc;
            zoomModal.classList.remove('hidden'); // Show modal
        }

        // Close zoom modal
        document.getElementById('closeZoom').addEventListener('click', function() {
            const zoomModal = document.getElementById('zoomModal');
            zoomModal.classList.add('hidden'); // Hide modal
        });

        // Allow zoom in/out by scrolling on the modal
        let zoomLevel = 1;
        document.getElementById('zoomModal').addEventListener('wheel', function(event) {
            if (event.deltaY < 0) {
                zoomLevel += 0.1; // Zoom in
            } else {
                zoomLevel -= 0.1; // Zoom out
            }
            zoomLevel = Math.max(0.5, Math.min(3, zoomLevel)); // Limit zoom level
            document.getElementById('zoomedImg').style.transform = `scale(${zoomLevel})`;
        });
    </script>
@endsection
