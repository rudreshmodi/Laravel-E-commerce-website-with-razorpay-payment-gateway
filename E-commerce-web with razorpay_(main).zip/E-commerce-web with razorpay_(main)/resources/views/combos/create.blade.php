@extends('layouts.app')

@section('title', 'Create Combo')

@section('content')
    <div class="container mx-auto">
        <!-- Breadcrumb -->
        <div class="flex px-5 py-3 text-gray-700 border border-gray-200 rounded-lg bg-gray-50 dark:bg-gray-800 dark:border-gray-700"
            aria-label="Breadcrumb">
            <ol class="inline-flex items-center space-x-1 md:space-x-2 rtl:space-x-reverse">
                <!-- Home Breadcrumb -->
                <li class="inline-flex items-center">
                    <a href="{{ route('dashboard') }}"
                        class="inline-flex items-center text-sm font-medium text-gray-700 hover:text-blue-600 dark:text-gray-400 dark:hover:text-white">
                        <svg class="w-3 h-3 me-2.5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor"
                            viewBox="0 0 20 20">
                            <path
                                d="m19.707 9.293-2-2-7-7a1 1 0 0 0-1.414 0l-7 7-2 2a1 1 0 0 0 1.414 1.414L2 10.414V18a2 2 0 0 0 2 2h3a1 1 0 0 0 1-1v-4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v4a1 1 0 0 0 1 1h3a2 2 0 0 0 2-2v-7.586l.293.293a1 1 0 0 0 1.414-1.414Z" />
                        </svg>
                        Home
                    </a>
                </li>

                <!-- Separator -->
                <li>
                    <div class="flex items-center">
                        <svg class="rtl:rotate-180 block w-3 h-3 mx-1 text-gray-400" aria-hidden="true"
                            xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="m1 9 4-4-4-4" />
                        </svg>
                        <a href="{{ route('combos.index') }}"
                            class="ms-1 text-sm font-medium text-gray-700 hover:text-blue-600 md:ms-2 dark:text-gray-400 dark:hover:text-white">Product
                            Combos</a>
                    </div>
                </li>

                <!-- Current Page -->
                <li aria-current="page">
                    <div class="flex items-center">
                        <svg class="rtl:rotate-180 w-3 h-3 mx-1 text-gray-400" aria-hidden="true"
                            xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="m1 9 4-4-4-4" />
                        </svg>
                        <span class="ms-1 text-sm font-medium text-gray-500 md:ms-2 dark:text-gray-400">Create
                            Product-Combo</span>
                    </div>
                </li>
            </ol>
        </div>

        <!-- Form Container -->
        <div class="w-full bg-white p-8 rounded-lg shadow-xl">
            <div class="flex justify-between items-center mb-6">
                <h2 class="text-3xl font-semibold text-gray-800"><i class="fas fa-plus-circle mr-2"></i> Create Combo</h2>
            </div>

            <!-- Combo Form -->
            <form action="{{ route('combos.store') }}" method="POST" enctype="multipart/form-data" class="space-y-6">
                @csrf

                <!-- Combo Name and Total Price -->
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <!-- Combo Name -->
                    <div class="mb-4 relative">
                        <label for="name" class="block text-sm font-medium text-gray-700">Combo Name <span
                                class="text-red-500">*</span></label>
                        <input type="text" name="name" id="name" value="{{ old('name') }}"
                            class="mt-1 block w-full px-4 py-2 pr-10 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <i class="fas fa-pen absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500"></i>
                        @error('name')
                            <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                        @enderror
                    </div>

                    <!-- Total Price Section with Modal Button -->
                    <div class="mb-4 relative">
                        <label for="total_price" class="block text-sm font-medium text-gray-700">Total Price <span
                                class="text-red-500">*</span></label>
                        <div
                            class="mt-1 flex items-center justify-between p-4 border border-gray-300 rounded-md shadow-sm bg-gray-50">
                            <span class="text-lg font-semibold text-gray-700">Total:</span>
                            <span class="text-xl font-bold text-blue-600"
                                id="total_price_display">₹{{ number_format(old('total_price', 0), 2) }}</span>
                            <button type="button" id="view-products-modal" class="ml-4 text-blue-600 hover:underline"><i
                                    class="fa-solid fa-calculator"></i>Discount</button>
                        </div>
                        <input type="hidden" name="total_price" id="total_price" value="{{ old('total_price', 0) }}">
                    </div>

                </div>

                <!-- Category and Subcategory Selection -->
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <!-- Category Selection -->
                    <div class="mb-4 relative">
                        <label for="categories_id" class="block text-sm font-medium text-gray-700">Category</label>
                        <select name="categories_id" id="category_id"
                            class="mt-1 block w-full px-4 py-2 pr-10 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                            <option value="" selected disabled>Select a Category</option>
                            @foreach ($categories as $category)
                                <option value="{{ $category->id }}">{{ $category->name }}</option>
                            @endforeach
                        </select>

                        @error('categories_id')
                            <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                        @enderror
                    </div>

                    <!-- Subcategory Selection -->
                    <div class="mb-4 relative">
                        <label for="subcategories_id" class="block text-sm font-medium text-gray-700">Subcategory</label>
                        <select name="subcategories_id" id="subcategory_id"
                            class="mt-1 block w-full px-4 py-2 pr-10 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                            <option value="" selected disabled>Select a Subcategory</option>
                            <!-- Subcategories will be loaded dynamically -->
                        </select>

                        @error('subcategory_id')
                            <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                        @enderror
                    </div>
                </div>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">

                    <!-- Product Selection (Custom Dropdown with Checkboxes) -->
                    <div class="mb-4 relative">
                        <label for="products" class="block text-sm font-medium text-gray-700">Products</label>

                        <!-- Custom Dropdown for Products with Checkboxes -->
                        <div id="product-dropdown" class="relative">
                            <!-- Dropdown Button -->
                            <button id="dropdown-toggle" type="button"
                                class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 flex justify-between items-baseline bg-gray-100  text-black text-start hover:bg-gray-50">
                                <span class="flex-grow">Select Products</span>
                                <!-- Dropdown icon -->
                                <span id="dropdown-icon"
                                    style="text-align:right; font-size:11px; margin-left: 56px; margin-top:-10px; color:black; font-weight: bold;">
                                    <i class="fas fa-chevron-down"></i>
                                </span>
                            </button>

                            <!-- Product Counter Display -->
                            <div class="absolute -top-10 right-0 mt-1 mr-4 text-sm font-bold text-blue-600"
                                id="product-counter">Selected Products:
                                0
                            </div>

                            <!-- Dropdown Menu -->
                            <div id="dropdown-menu"
                                class="absolute z-10 hidden bg-white border border-gray-300 rounded-md shadow-md w-full mt-1 max-h-60 overflow-y-auto transition-all ease-in-out duration-300 transform origin-top">
                                <!-- Checkboxes for products -->
                                <div class="py-2">
                                    @foreach ($products as $product)
                                        <label class="block px-4 py-2 cursor-pointer hover:bg-gray-100 product-option">
                                            <input type="checkbox" name="products[]" value="{{ $product->id }}"
                                                data-price="{{ $product->price }}" class="product-checkbox">
                                            {{ $product->name }}
                                        </label>
                                    @endforeach
                                </div>
                            </div>
                        </div>

                        @error('products')
                            <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                        @enderror
                    </div>

                    <!-- Discount Price -->
                    <div class="mb-4 relative">
                        <label for="disc_price" class="block text-sm font-medium text-gray-700">Discount Price</label>
                        <input type="text" name="disc_price" id="disc_price" value="{{ old('disc_price') }}"
                            class="mt-1 block w-full px-4 py-2 pr-10 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <i class="fas fa-percent absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500"></i>

                        <p class="mt-2 text-sm text-gray-500" id="discounted-price">Suggested Discount Price: ₹0.00</p>
                        @error('disc_price')
                            <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                        @enderror
                    </div>
                </div>
                <!-- Combo Description -->
                <div class="mb-4 relative">
                    <label for="description" class="block text-sm font-medium text-gray-700">
                        Combo Description
                    </label>
                    <div class="relative">
                        <textarea name="description" id="description" rows="3" maxlength="150" oninput="updateCharCount()"
                            class="mt-1 block w-full px-4 py-2 pr-10 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">{{ old('description') }}</textarea>
                        <i class="fas fa-pencil-alt absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                    </div>
                    <div class="right-18 text-sm text-gray-500 mt-1">
                        <span id="charCount">0</span> / 100
                    </div>
                    @error('description')
                        <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Image Upload -->
                <div class="mb-4 relative">
                    <label for="image" class="block text-sm font-medium text-gray-700">Combo Image</label>
                    <input type="file" name="image" id="image" accept="image/*"
                        class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">

                    @error('image')
                        <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                    @enderror

                    <!-- Image Preview Section -->
                    <div id="image-preview-container" class="mt-4">
                        <img id="image-preview" src="" alt="Image Preview"
                            class="hidden w-20 h-auto rounded-md shadow-md">
                    </div>
                </div>


                <!-- Buttons -->
                <div class="flex justify-end gap-4 mt-6">
                    <a href="{{ route('combos.index') }}"
                        class="bg-gray-300 text-gray-800 px-4 py-2 rounded-md hover:bg-gray-400 transition">Cancel</a>
                    <button type="submit"
                        class="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 transition">Create
                        Combo</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Product Details Modal -->
    <div id="product-modal" class="fixed inset-0 bg-gray-800 bg-opacity-50 hidden flex justify-center items-center z-50">
        <div class="bg-white p-6 rounded-lg shadow-xl w-1/3">
            <h3 class="text-xl font-semibold mb-4">Selected Products</h3>
            <div class="overflow-x-auto" style="overflow-x: auto;">
                <table class="min-w-full bg-transparent table-auto shadow-lg rounded-md"
                    style="min-width: 100%; background-color: transparent; table-layout: auto; box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1); border-radius: 8px;">
                    <thead>
                        <tr class="bg-gray-100 text-gray-700" style="background-color: #f7fafc; color: #4a5568;">
                            <th class="py-2 px-4 text-center" style="padding: 12px 16px;font-weight: bold;">Product</th>
                            <th class="py-2 px-4 text-center" style="padding: 12px 16px; font-weight: bold;">Price</th>
                        </tr>
                    </thead>
                    <tbody id="product-list" style="background-color: white;">
                        <!-- Dynamically populated product list will appear here -->
                    </tbody>
                </table>
            </div>

            <div class="mt-4">
                <label for="discount-select" class="block text-sm font-medium text-gray-700">Select Discount</label>
                <select id="discount-select"
                    class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <option value="0" selected>No Discount</option>
                    <option value="5">5%</option>
                    <option value="10">10%</option>
                    <option value="15">15%</option>
                    <option value="20">20%</option>
                    <option value="25">25%</option>
                    <option value="30">30%</option>
                    <option value="35">35%</option>
                    <option value="40">40%</option>
                </select>
                <p class="mt-2 text-sm text-gray-600" id="discounted-price-text">Discounted Price: ₹0.00</p>
            </div>

            <div class="mt-6 flex justify-between">
                <button type="button" id="close-modal"
                    class="bg-gray-300 text-gray-800 px-4 py-2 rounded-md hover:bg-gray-400">Close</button>
                <button type="button" id="apply-discount"
                    class="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700">Apply Discount</button>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const dropdownToggle = document.getElementById('dropdown-toggle');
            const dropdownMenu = document.getElementById('dropdown-menu');
            const dropdownIcon = document.getElementById('dropdown-icon');
            const productCheckboxes = dropdownMenu.querySelectorAll('input[type="checkbox"]');
            const totalPriceDisplay = document.getElementById('total_price_display');
            const totalPriceInput = document.getElementById('total_price');
            const productCounter = document.getElementById('product-counter');
            const productModal = document.getElementById('product-modal');
            const productList = document.getElementById('product-list');
            const discountSelect = document.getElementById('discount-select');
            const discountedPriceText = document.getElementById('discounted-price-text');
            const viewProductsModal = document.getElementById('view-products-modal');
            const closeModal = document.getElementById('close-modal');
            const applyDiscount = document.getElementById('apply-discount');
            const fileInput = document.getElementById('image');
            const imagePreviewContainer = document.getElementById('image-preview-container');
            const imagePreview = document.getElementById('image-preview');
            const discountPriceInput = document.getElementById('disc_price');
            const charCount = document.getElementById('charCount');
            const categoryId = document.getElementById('category_id');
            const subcategoryDropdown = document.getElementById('subcategory_id');

            let selectedProducts = [];
            const minSelection = 2;
            const maxSelection = 6;

            // Show and hide the modal
            viewProductsModal.addEventListener('click', () => productModal.classList.remove('hidden'));
            closeModal.addEventListener('click', () => productModal.classList.add('hidden'));

            // Update total price and selected product count
            productCheckboxes.forEach(checkbox => {
                checkbox.addEventListener('change', function() {
                    let totalPrice = 0,
                        selectedCount = 0;
                    selectedProducts = [];
                    productCheckboxes.forEach(checkbox => {
                        if (checkbox.checked) {
                            selectedCount++;
                            selectedProducts.push({
                                name: checkbox.parentElement.textContent.trim(),
                                price: parseFloat(checkbox.getAttribute(
                                    'data-price'))
                            });
                            totalPrice += parseFloat(checkbox.getAttribute('data-price'));
                        }
                    });

                    productList.innerHTML = selectedProducts.map(product =>
                        `<tr><td class="py-2 px-4 text-sm text-black">${product.name}</td><td class="py-2 px-4 text-blue-700">₹${product.price.toFixed(2)}</td></tr>`
                    ).join('');

                    totalPriceDisplay.textContent = `₹${totalPrice.toFixed(2)}`;
                    totalPriceInput.value = totalPrice.toFixed(2);
                    productCounter.textContent = `Selected Products: ${selectedCount}`;
                    let discountPercentage = parseFloat(discountSelect.value);
                    discountedPriceText.textContent =
                        `Discounted Price: ₹${(totalPrice - totalPrice * (discountPercentage / 100)).toFixed(2)}`;
                });
            });

            // Update discounted price when the discount is changed
            discountSelect.addEventListener('change', function() {
                let totalPrice = parseFloat(totalPriceInput.value);
                let discountPercentage = parseFloat(discountSelect.value);
                discountedPriceText.textContent =
                    `Discounted Price: ₹${(totalPrice - totalPrice * (discountPercentage / 100)).toFixed(2)}`;
            });

            // Apply discount
            applyDiscount.addEventListener('click', function() {
                let discountedPrice = parseFloat(discountedPriceText.textContent.replace(
                    'Discounted Price: ₹', ''));
                document.getElementById('disc_price').value = discountedPrice.toFixed(2);
                productModal.classList.add('hidden');
            });

            // Toggle dropdown visibility
            dropdownToggle.addEventListener('click', function() {
                dropdownMenu.classList.toggle('hidden');
                dropdownIcon.innerHTML = dropdownMenu.classList.contains('hidden') ?
                    '<i class="fas fa-chevron-down"></i>' :
                    '<i class="fas fa-chevron-up"></i>';
            });

            // Ensure product selection meets min/max criteria
            productCheckboxes.forEach(checkbox => {
                checkbox.addEventListener('change', function() {
                    let selectedCount = [...productCheckboxes].filter(checkbox => checkbox.checked)
                        .length;
                    if (selectedCount < minSelection) {
                        productCounter.textContent =
                            `Selected Products: ${selectedCount} (Minimum 2 products required)`;
                        productCounter.classList.add('text-red-500');
                    } else if (selectedCount > maxSelection) {
                        productCounter.textContent =
                            `Selected Products: ${maxSelection} (Maximum 6 products allowed)`;
                        productCounter.classList.add('text-red-500');
                        checkbox.checked = false;
                    } else {
                        productCounter.textContent = `Selected Products: ${selectedCount}`;
                        productCounter.classList.remove('text-red-500');
                    }
                });
            });

            // Ensure discount price doesn't exceed total price
            discountPriceInput.addEventListener('input', function() {
                let discountPrice = parseFloat(discountPriceInput.value) || 0;
                let totalPrice = parseFloat(totalPriceInput.value);
                if (discountPrice > totalPrice) discountPriceInput.value = totalPrice.toFixed(2);
            });

            // Image preview functionality
            fileInput.addEventListener('change', function(event) {
                const file = event.target.files[0];
                if (file && file.type.startsWith('image/')) {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        imagePreview.src = e.target.result;
                        imagePreview.classList.remove('hidden');
                        imagePreviewContainer.classList.remove('hidden');
                    };
                    reader.readAsDataURL(file);
                } else {
                    imagePreview.classList.add('hidden');
                    imagePreviewContainer.classList.add('hidden');
                }
            });

            // Category change event to update subcategories
            categoryId.addEventListener('change', function() {
                const categoryIdValue = this.value;
                subcategoryDropdown.innerHTML = '<option value="">Select Subcategory</option>';
                if (categoryIdValue) {
                    fetch(`/get-subcategories/${categoryIdValue}`)
                        .then(response => response.json())
                        .then(data => {
                            data.forEach(subcategory => {
                                const option = document.createElement('option');
                                option.value = subcategory.id;
                                option.textContent = subcategory.name;
                                subcategoryDropdown.appendChild(option);
                            });
                        })
                        .catch(error => console.error('Error fetching subcategories:', error));
                }
            });

            // Character count update for textarea
            document.getElementById('description').addEventListener('input', function() {
                charCount.textContent = this.value.length;
            });
        });
    </script>


@endsection
