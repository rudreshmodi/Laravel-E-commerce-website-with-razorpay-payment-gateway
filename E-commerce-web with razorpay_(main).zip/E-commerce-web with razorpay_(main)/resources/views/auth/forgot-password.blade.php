<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Include Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body class="bg-gray-100 flex items-center justify-center h-screen">


    <div class="bg-white shadow-md rounded-lg p-6 w-full max-w-md">
        <h2 class="text-2xl font-bold text-center mb-4">Forgot Password</h2>

        <!-- Success session message -->
        @if (session('success'))
            <p class="text-green-600 mb-4">{{ session('success') }}</p>
        @endif

        <!-- Error session message -->
        @if (session('error'))
            <p class="text-red-600 mb-4">{{ session('error') }}</p>
        @endif

        <form action="{{ route('password.email') }}" method="POST" class="space-y-4">
            @csrf

            <div class="relative">
                <label for="email" class="block text-gray-700 font-medium mb-1">Email <span class="text-red-600">*</span></label>
                <input type="email" name="email" id="email"
                    class="w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Enter your email" value="{{ old('email') }}">
                <span class="absolute right-3 transform -translate-y-1/2 cursor-pointer text-gray-500"
                    style="top: 50px;">
                    <i class="fas fa-envelope"></i>
                </span>

                <!-- Display server-side error for email -->
                @error('email')
                    <p class="text-red-600 mt-1">{{ $message }}</p>
                @enderror
            </div>

            <button type="submit"
                class="w-full bg-blue-500 text-white py-2 rounded hover:bg-blue-600 transition">
                <i class="fas fa-paper-plane mr-2"></i> Send Reset Link
            </button>
        </form>

        <div class="mt-4 text-center">
            <a href="{{ route('home') }}" class="text-blue-500 hover:underline ml-1">
                <i class="fas fa-arrow-left mr-2"></i>Back to Login
            </a>
        </div>
    </div>

    @if (session('success'))
            <div id="successToast"
                class="fixed top-10 right-10 z-50 bg-green-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
                <!-- Success Icon -->
                <i class="fas fa-check-circle text-white text-2xl"></i>
                <!-- Success Message -->
                <span>{{ session('success') }}</span>
            </div>

            <script>
                setTimeout(() => {
                    document.querySelector('#successToast').style.display = 'none';
                }, 4000);
            </script>
        @endif

        <!-- Error Toast -->
        @if (session('error'))
            <div id="errorToast"
                class="fixed top-10 right-10 z-50 bg-red-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
                <!-- Error Icon -->
                <i class="fas fa-times-circle text-white text-2xl"></i>
                <!-- Error Message -->
                <span>{{ session('error') }}</span>
            </div>

            <script>
                setTimeout(() => {
                    document.querySelector('#errorToast').style.display = 'none';
                }, 4000);
            </script>
        @endif
</body>
</html>
