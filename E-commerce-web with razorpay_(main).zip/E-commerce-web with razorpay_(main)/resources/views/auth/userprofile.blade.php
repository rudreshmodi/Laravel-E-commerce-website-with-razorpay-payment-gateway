@extends('layouts.user')

@section('content')
    <div class="flex items-center justify-center">
        <div class="bg-white shadow-lg rounded-lg p-8 w-full max-w-lg">
            <h2 class="text-3xl font-semibold text-center mb-6 text-gray-800">My Profile</h2>

            @if (session('success'))
                <div id="successToast"
                    class="fixed top-10 right-10 z-50 bg-green-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
                    <i class="fas fa-check-circle text-white text-2xl"></i>
                    <span>{{ session('success') }}</span>
                </div>
                <script>
                    setTimeout(() => {
                        document.querySelector('#successToast').style.display = 'none';
                    }, 4000);
                </script>
            @endif

            @if (session('error'))
                <div id="errorToast"
                    class="fixed top-10 right-10 z-50 bg-red-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
                    <i class="fas fa-times-circle text-white text-2xl"></i>
                    <span>{{ session('error') }}</span>
                </div>
                <script>
                    setTimeout(() => {
                        document.querySelector('#errorToast').style.display = 'none';
                    }, 4000);
                </script>
            @endif

            <!-- Profile Image Update Form -->
            <form action="{{ route('profile.update.userimage') }}" method="POST" enctype="multipart/form-data">
                @csrf
                @method('PUT')

                <!-- Merged Image Preview and File Input -->
                <div class="relative flex justify-center mb-8">
                    <!-- Profile Image Preview -->
                    <img id="profileImagePreview"
                        src="{{ asset('storage/' . ($user->profile_image ?? 'profile_images/Profile.png')) }}"
                        alt="Profile Picture"
                        class="w-32 h-32 rounded-full object-cover border-4 border-indigo-500 shadow-lg cursor-pointer">

                    <!-- Hidden File Input for Image Upload -->
                    <input type="file" name="profile_image" id="profile_image"
                        class="absolute inset-0 w-full h-full opacity-0 cursor-pointer rounded-full"
                        onchange="previewImage(event)" accept="image/*">

                    <!-- Pencil Icon Positioned at the Bottom-Right -->
                    <label for="profile_image" class="absolute bottom-0 bg-white right-40 rounded-full p-1 cursor-pointer">
                        <i class="fas fa-pencil-alt text-indigo-500 hover:text-indigo-700 text-xl"></i>
                    </label>
                </div>

                @error('profile_image')
                    <div class="text-red-500 text-sm text-center mt-2">{{ $message }}</div>
                @enderror

                <!-- Submit Button -->
                <div class="text-center">
                    <button type="submit"
                        class="w-full md:w-auto bg-indigo-500 text-white px-6 py-3 rounded-lg text-center hover:bg-indigo-600 transition duration-300 ease-in-out">
                        Update Profile Image
                    </button>
                </div>
            </form>

            <!-- User Details -->
            <div class="space-y-6 mt-6">
                <div class="flex justify-between">
                    <label for="name" class="text-gray-700 font-medium">Name</label>
                    <div class="text-gray-800">{{ $user->name }}</div>
                </div>

                <div class="flex justify-between">
                    <label for="email" class="text-gray-700 font-medium">Email</label>
                    <div class="text-gray-800">{{ $user->email }}</div>
                </div>

                <div class="flex justify-between">
                    <label for="created_at" class="text-gray-700 font-medium">Joined</label>
                    <div class="text-gray-800">{{ $user->created_at->format('F j, Y') }}</div>
                </div>
            </div>

            <!-- Action Buttons -->
            <div class="mt-8 flex justify-between gap-4">
                <a href="{{ route('dashboard') }}"
                    class="w-full md:w-auto bg-gray-300 text-gray-700 px-6 py-3 rounded-lg text-center hover:bg-gray-400 transition duration-300 ease-in-out">
                    Back to Dashboard
                </a>
                <a href="{{ route('change-password.form') }}"
                    class="w-full md:w-auto bg-indigo-500 text-white px-6 py-3 rounded-lg text-center hover:bg-indigo-600 transition duration-300 ease-in-out">
                    Change Password
                </a>
            </div>
        </div>
    </div>

    <script>
        // Function to preview the selected image
        function previewImage(event) {
            const file = event.target.files[0];
            const reader = new FileReader();

            reader.onload = function(e) {
                const preview = document.getElementById('profileImagePreview');
                preview.src = e.target.result; // Set the source to the selected file's data URL
            }

            if (file) {
                reader.readAsDataURL(file); // Read the file as a Data URL
            } else {
                // If no file is selected, set the default image again
                document.getElementById('profileImagePreview').src =
                    '{{ asset('storage/' . ($user->profile_image ?? 'profile_images/Profile.png')) }}';
            }
        }
    </script>
@endsection
