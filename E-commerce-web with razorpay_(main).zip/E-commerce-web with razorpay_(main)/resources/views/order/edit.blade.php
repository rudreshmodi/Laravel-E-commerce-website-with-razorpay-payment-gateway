@extends('layouts.app')

@section('title', 'Edit Product')

@section('content')
<div class="container mx-auto mt-0">

    <!-- Breadcrumb Navigation -->
    <nav class="flex text-sm text-gray-600 mb-6 items-center">
        <a href="{{ route('dashboard') }}"
            class="flex items-center {{ Request::is('dashboard') ? 'text-blue-500' : '' }}">
            <span class="text-xs px-2 py-1 bg-gray-200 rounded-full">Home</span>
        </a>
        <span class="mx-2 text-xs">/</span>
        <a href="{{ route('products.index') }}"
            class="flex items-center {{ Request::is('products') || Request::is('products/*') ? 'text-blue-500' : '' }}">

            <span class="text-xs px-2 py-1 bg-gray-200 rounded-full">Products</span>
        </a>
        <span class="mx-2 text-xs">/</span>
        <span class="text-xs text-gray-500">Edit</span>
    </nav>

    <!-- Full-Screen Width Card Container for the Form -->
    <div class="w-full bg-white p-8 rounded-lg shadow-xl">
        <!-- Flex container to align Button and Page Title -->
        <div class="flex justify-between items-center mb-6">
            <h2 class="text-3xl font-semibold text-gray-800"><i class="fas fa-edit mr-2"></i> View Order</h2>
        </div>

        <!-- Form to Edit Product -->
        <form action="{{ route('order.update', $order->id) }}" method="POST" enctype="multipart/form-data"
            class="space-y-6">
            @csrf
            @method('PUT')

            <!-- Product Category -->
            <div class="mb-4">
                <label for="category_id" class="block text-sm font-medium text-gray-700">
                    Category <span class="text-red-500">*</span>
                </label>

                @error('category_id')
                <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                @enderror
            </div>

            <!-- Product Name -->
            <div class="mb-4">
                <label for="name" class="block text-sm font-medium text-gray-700">
                    Product Name <span class="text-red-500">*</span>
                </label>
                <div class="relative">
                    <i class="fas fa-tag absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                </div>
                @error('name')
                <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                @enderror
            </div>

            <!-- Product Description -->
            <div class="mb-4">
                <label for="description" class="block text-sm font-medium text-gray-700">
                    Product Description <span class="text-red-500">*</span>
                </label>



                @error('description')
                <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                @enderror
            </div>

            <!-- Product Price -->
            <div class="mb-4">
                <label for="price" class="block text-sm font-medium text-gray-700">
                    Product Price <span class="text-red-500">*</span>
                </label>

                @error('price')
                <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                @enderror
            </div>

            <!-- Product Image (Optional) -->
            <div class="mb-4">
                <label for="image" class="block text-sm font-medium text-gray-700">
                    Product Image (Optional)
                </label>
                <input type="file" name="image" id="image" accept="image/*"
                    class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                    onchange="previewImage()">

                <!-- Error message for image validation -->
                <div id="imageError"></div>

                <!-- New Image Preview -->
                <div id="imagePreviewContainer" class="mt-2 hidden">
                    <img id="imagePreview" src="#" alt="New Image Preview"
                        class="w-32 h-32 object-cover rounded">
                    <p class="mt-2 text-sm text-gray-500">New Image</p>
                </div>

                @error('image')
                <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                @enderror
            </div>


            <!-- Submit Button -->
            <div class="flex justify-end space-x-4">
                <!-- Cancel Button -->
                <a href="{{ route('products.index') }}"
                    class="bg-gray-300 text-gray-800 px-6 py-2 rounded hover:bg-gray-400 transition duration-300 flex items-center">
                    <i class="fas fa-times-circle mr-2"></i> Cancel
                </a>
                <!-- Submit Button -->
                <button type="submit"
                    class="bg-blue-500 text-white px-6 py-2 rounded hover:bg-blue-600 transition duration-300 flex items-center">
                    <i class="fas fa-save mr-2"></i>
                    Save Changes
                </button>
            </div>

        </form>
    </div>

</div>
@if (session('success'))
<div id="successToast"
    class="fixed top-10 right-10 z-50 bg-green-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
    <!-- Success Icon -->
    <i class="fas fa-check-circle text-white text-2xl"></i>
    <!-- Success Message -->
    <span>{{ session('success') }}</span>
</div>

<script>
    setTimeout(() => {
        document.querySelector('#successToast').style.display = 'none';
    }, 4000);
</script>
@endif

<!-- Error Toast -->
@if (session('error'))
<div id="errorToast"
    class="fixed top-10 right-10 z-50 bg-red-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
    <!-- Error Icon -->
    <i class="fas fa-times-circle text-white text-2xl"></i>
    <!-- Error Message -->
    <span>{{ session('error') }}</span>
</div>

<script>
    setTimeout(() => {
        document.querySelector('#errorToast').style.display = 'none';
    }, 4000);
</script>
@endif

<script>
    // Function to update character count for description field
    function updateCharCount() {
        const textarea = document.getElementById('description');
        const charCount = document.getElementById('charCount');
        charCount.textContent = textarea.value.length; // Update character count
    }

    // Function to preview new image before upload with validation
    // Function to preview new image before upload with validation
    function previewImage() {
        const fileInput = document.getElementById('image');
        const imagePreview = document.getElementById('imagePreview');
        const imagePreviewContainer = document.getElementById('imagePreviewContainer');
        const errorContainer = document.getElementById('imageError');
        const file = fileInput.files[0];

        // Clear previous error message
        if (errorContainer) {
            errorContainer.remove();
        }

        if (file) {
            // Validate image size (max 10MB)
            if (file.size > 10 * 1024 * 1024) { // 10MB in bytes
                const sizeError = document.createElement('p');
                sizeError.textContent = 'Image size must be less than or equal to 10MB.';
                sizeError.classList.add('mt-2', 'text-sm', 'text-red-500');
                fileInput.insertAdjacentElement('afterend', sizeError);
                return;
            }

            // Validate image type (jpeg, png, jpg)
            const validExtensions = ['image/jpeg', 'image/png', 'image/jpg'];
            if (!validExtensions.includes(file.type)) {
                const typeError = document.createElement('p');
                typeError.textContent = 'Only image files (jpeg, png, jpg) are allowed.';
                typeError.classList.add('mt-2', 'text-sm', 'text-red-500');
                fileInput.insertAdjacentElement('afterend', typeError);
                return;
            }

            // Preview the image if valid
            const reader = new FileReader();
            reader.onload = function(e) {
                imagePreview.src = e.target.result;
                imagePreviewContainer.classList.remove('hidden');
            };
            reader.readAsDataURL(file);
        }
    }
</script>
@endsection
