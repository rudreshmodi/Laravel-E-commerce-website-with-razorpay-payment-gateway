<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use Carbon\Carbon;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Create some sample users
        $users = [
            [
                'name' => 'Admin User',
                'email' => 'admin@example.com',
                'mobile_number' => '1234567890',
                'password' => Hash::make('password'), // Encrypt the password
                'role' => 'admin',
                'email_verification_token' => \Illuminate\Support\Str::random(60),
                'otp' => rand(100000, 999999),
                'otp_verified_at' => Carbon::now(),
                'email_verified_at' => Carbon::now(),
            ],
            [
                'name' => 'John Doe',
                'email' => 'john.doe@example.com',
                'mobile_number' => '9876543210',
                'password' => Hash::make('password123'), // Encrypt the password
                'role' => 'user',
                'email_verification_token' => \Illuminate\Support\Str::random(60),
                'otp' => rand(100000, 999999),
                'otp_verified_at' => null,
                'email_verified_at' => null,
            ],
            [
                'name' => 'Jane Smith',
                'email' => 'jane.smith@example.com',
                'mobile_number' => '1112223333',
                'password' => Hash::make('securepassword'), // Encrypt the password
                'role' => 'user',
                'email_verification_token' => \Illuminate\Support\Str::random(60),
                'otp' => rand(100000, 999999),
                'otp_verified_at' => Carbon::now(),
                'email_verified_at' => Carbon::now(),
            ],
        ];

        // Insert users into the database
        foreach ($users as $user) {
            User::create($user);
        }
    }
}
