<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Product;
use App\Models\Subcategory;
use Dompdf\Dompdf;
use Dompdf\Options;
use Endroid\QrCode\QrCode;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use PDF;
use Symfony\Component\HttpFoundation\StreamedResponse;

class ProductController extends Controller
{
    /**
     * Display a listing of the products.
     */
    public function index(Request $request)
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }


        // Get all categories and subcategories
        $categories = Category::whereNull('deleted_at')->get();
        $subcategories = Subcategory::whereNull('deleted_at')->get(); // Exclude trashed subcategories

        // Initialize the query to fetch products, along with related category and subcategory
        $query = Product::with(['category', 'subcategory']);  // Make sure to load subcategory as well

        // Apply filters based on the request
        if ($request->has('search') && $request->search != '') {
            $query->where('name', 'like', '%' . $request->search . '%');
        }

        if ($request->has('category_id') && $request->category_id != '') {
            $query->where('category_id', $request->category_id);
        }

        if ($request->has('subcategory_id') && $request->subcategory_id != '') {
            $query->where('subcategory_id', $request->subcategory_id);
        }

        if ($request->has('status') && $request->status != '') {
            $query->where('status', $request->status);
        }

        // Paginate the results
        $products = $query->paginate(5);

        // Return the view with the necessary data
        return view('products.index', compact('products', 'categories', 'subcategories'));
    }


    /**
     * Show the form for creating a new product.
     */
    public function create()
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }

        $categories = Category::whereNull('deleted_at')->get();
        $subcategories = Subcategory::whereNull('deleted_at')->get(); // Exclude trashed subcategories
        return view('products.create', compact('categories', 'subcategories'));
    }

    /**
     * Store a newly created product in storage.
     */
    public function store(Request $request)
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }


        // Custom validation messages
        $messages = [
            'name.required' => 'The product name is required.',
            'name.string' => 'The product name must be a string.',
            'name.min' => 'The product name must be at least 3 characters long.',
            'name.max' => 'The product name cannot exceed 255 characters.',

            'description.required' => 'The description is required.',
            'description.string' => 'The description must be a string.',
            'description.max' => 'The description cannot exceed 1000 characters.',

            'price.required' => 'The price is required.',
            'price.numeric' => 'The price must be a valid number.',
            'price.min' => 'The price cannot be less than zero.',

            'category_id.required' => 'The category is required.',
            'category_id.exists' => 'The selected category is invalid.',

            'subcategory_id.required' => 'The subcategory is required.',
            'subcategory_id.exists' => 'The selected subcategory is invalid.',

            'images.required' => 'At least one image is required.',
            'images.array' => 'The images field must be an array.',
            'images.*.required' => 'Each image must be provided.',
            'images.*.image' => 'Each file must be an image.',
            'images.*.mimes' => 'Each image must be a file of type: jpeg, png, jpg, or webp.',
            'images.*.max' => 'Each image cannot exceed 10MB in size.',

            'status.required' => 'The status is required.',
            'status.in' => 'The status must be either "active" or "inactive".',
        ];

        // Validate input data
        $validated = $request->validate([
            'name' => 'required|string|min:3|max:255',
            'description' => 'required|string|max:1000',
            'price' => 'required|numeric|min:0',
            'category_id' => 'required|exists:categories,id',
            'subcategory_id' => 'required|exists:subcategories,id',
            'images' => 'required|array',
            'images.*' => 'required|image|mimes:jpeg,png,jpg,webp|max:10240',
            'status' => 'required|in:active,inactive',
        ], $messages); // Pass custom messages here

        // Handle multiple image uploads if images are provided
        $imagePaths = [];
        if ($request->hasFile('images')) {
            foreach ($request->file('images') as $image) {
                $imagePaths[] = $image->store('products', 'public');
            }
        }

        // Store the paths as a comma-separated string
        $validated['images'] = implode(',', $imagePaths);

        // Create the product with the validated data
        Product::create($validated);

        // Flash a success message and redirect
        session()->flash('success', 'Product created successfully!');
        return redirect()->route('products.index');
    }






    /**
     * Show the form for editing the specified product.
     */
    public function edit(Product $product)
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }


        $categories = Category::whereNull('deleted_at')->get();

        // Get subcategories related to the product's category
        $subcategories = $product->category->subcategories; // Use the category relation of the product

        return view('products.edit', compact('product', 'categories', 'subcategories'));
    }


    public function update(Request $request, $id)
    {

        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }

        // Custom validation messages
        $messages = [
            'name.required' => 'The product name is required.',
            'name.string' => 'The product name must be a string.',
            'name.max' => 'The product name cannot exceed 255 characters.',

            'category_id.required' => 'The category is required.',
            'category_id.exists' => 'The selected category is invalid.',

            'subcategory_id.required' => 'The subcategory is required.',
            'subcategory_id.exists' => 'The selected subcategory is invalid.',

            'description.required' => 'The description is required.',
            'description.string' => 'The description must be a string.',
            'description.max' => 'The description cannot exceed 255 characters.',

            'price.required' => 'The price is required.',
            'price.numeric' => 'The price must be a valid number.',
            'price.min' => 'The price cannot be less than zero.',

            'status.required' => 'The status is required.',
            'status.in' => 'The status must be either "active" or "inactive".',

            'images.required' => 'At least one image is required.',
            'images.array' => 'The images field must be an array.',
            'images.*.required' => 'Each image must be provided.',
            'images.*.image' => 'Each file must be an image.',
            'images.*.mimes' => 'Each image must be a file of type: jpeg, png, jpg, or webp.',
            'images.*.max' => 'Each image cannot exceed 10MB in size.',
        ];

        // Validate input data
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'category_id' => 'required|exists:categories,id',
            'subcategory_id' => 'required|exists:subcategories,id',
            'description' => 'required|string|max:255',
            'price' => 'required|numeric|min:0',
            'status' => 'required|in:active,inactive',
            'images' => 'required|array',
            'images.*' => 'required|image|mimes:jpeg,png,jpg,webp|max:10240',
        ], $messages); // Pass custom validation messages

        // Find the product by ID
        $product = Product::findOrFail($id);

        // Prepare the data (excluding images for now)
        $data = $request->only(['name', 'category_id', 'subcategory_id', 'description', 'price', 'status']);

        // Handle image uploads if images are provided
        if ($request->hasFile('images')) {
            $imagePaths = [];

            foreach ($request->file('images') as $image) {
                // Store each image and get the path
                $imagePath = $image->store('product_images', 'public'); // Store in the public disk
                $imagePaths[] = $imagePath; // Add the path to the array
            }

            // Store the image paths as a comma-separated string
            $data['images'] = implode(',', $imagePaths);
        }

        // Update the product with the new data
        $product->update($data);

        // Redirect with a success message
        return redirect()->route('products.index')->with('success', 'Product updated successfully.');
    }



    /**
     * Soft delete the specified product from storage.
     */
    public function destroy(Product $product)
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }


        try {
            $product->delete();
            session()->flash('success', 'Product deleted successfully!');
        } catch (\Exception $e) {
            session()->flash('error', 'Failed to delete product.');
        }

        return redirect()->route('products.index');
    }

    /**
     * Restore the specified soft-deleted product.
     */
    public function restore($id)
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }

        $product = Product::withTrashed()->findOrFail($id);
        $product->restore();

        session()->flash('success', 'Product restored successfully!');
        return redirect()->route('products.index');
    }

    /**
     * Update product status (active/inactive).
     */
    public function updateStatus(Product $product)
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }


        $product->status = $product->status === 'active' ? 'inactive' : 'active';
        $product->save();

        return redirect()->route('products.index')->with('success', 'Product status updated successfully.');
    }

    /**
     * Display the specified product.
     */
    public function show($id)
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }


        $product = Product::with('category')->findOrFail($id);

        return view('products.show', compact('product'));
    }

    /**
     * Display products in a card layout.
     */
    public function card()
    {
        $products = Product::paginate(8); // Show 8 products per page
        return view('products.card-view', compact('products'));
    }


    /**
     * Show the list of deleted products.
     */
    public function deleted()
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }


        $deletedProducts = Product::onlyTrashed()->get();

        return view('products.deleted', compact('deletedProducts'));
    }

    public function getSubcategories($categoryId)
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }

        // Fetch subcategories based on category ID
        $subcategories = Subcategory::where('category_id', $categoryId)->get();

        // Return the subcategories as a JSON response
        return response()->json($subcategories);
    }

    /**
     * Generate a QR code for the product.
     */
    public function generateProductQrCode($productId)
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }

        $product = Product::findOrFail($productId);
        $productData = sprintf(
            "Product Name: %s\nDescription: %s\nPrice: $%0.2f\nStatus: %s\nCategory: %s",
            $product->name,
            $product->description,
            $product->price,
            ucfirst($product->status),
            $product->category->name
        );

        $qrCode = new QrCode($productData);
        $qrCode->setSize(300);
        $qrCode->setEncoding('UTF-8');
        $qrCode->setErrorCorrectionLevel(\Endroid\QrCode\ErrorCorrectionLevel::HIGH);

        return response($qrCode->writeString(), 200)->header('Content-Type', 'image/png');
    }

    /**
     * Export products data as a CSV file.
     */
    public function exportToCsv()
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }

        if (!Auth::check()) {
            return redirect()->route('home');
        }

        $fileName = 'trashed_products_' . date('Ymd_His') . '.csv';
        $headers = [
            'Content-Type' => 'text/csv',
            'Content-Disposition' => "attachment; filename=\"$fileName\"",
        ];

        $callback = function () {
            $fileHandle = fopen('php://output', 'w');

            // Add CSV header row
            fputcsv($fileHandle, ['ID', 'Name', 'Description', 'Price', 'Category', 'Status', 'Created At', 'Updated At', 'Deleted At']);

            // Fetch only soft-deleted products (trashed products)
            $trashedProducts = Product::withTrashed()->with('category')->get();

            // Loop through the trashed products and add them to the CSV
            foreach ($trashedProducts as $product) {
                $deletedAt = $product->deleted_at ? $product->deleted_at->format('M j, Y, g:i a') : 'Not Deleted';

                // Write product data to CSV
                fputcsv($fileHandle, [
                    $product->id,
                    $product->name,
                    $product->description,
                    $product->price,
                    $product->category->name ?? 'N/A',
                    ucfirst($product->status),
                    $product->created_at->format('M j, Y, g:i a'),
                    $product->updated_at->format('M j, Y, g:i a'),
                    $deletedAt,  // Format deleted_at or show 'N/A'
                ]);
            }

            fclose($fileHandle);
        };

        return new StreamedResponse($callback, 200, $headers);
    }





    public function exportToPdf()
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }


        // Fetch all products data, including those that are soft deleted
        $products = Product::with('category')->get();

        // Separate products into deleted and non-deleted
        $nonDeletedProducts = $products->whereNull('deleted_at');
        // Fetch only soft-deleted products using the built-in SoftDeletes method
        $deletedProducts = Product::onlyTrashed()->get();

        // Prepare the data for rendering in the PDF
        $html = view('products.pdf', compact('nonDeletedProducts', 'deletedProducts'))->render();

        // Configure Dompdf options
        $options = new Options();
        $options->set('isHtml5ParserEnabled', true); // Enable HTML5 parsing
        $options->set('isPhpEnabled', true); // Allow PHP function calls for URLs
        $options->set('isRemoteEnabled', true); // Allow loading remote images

        $dompdf = new Dompdf($options);
        $dompdf->loadHtml($html);
        $dompdf->setPaper('A4', 'landscape');
        $dompdf->render();

        // Stream the generated PDF
        return $dompdf->stream('products_' . date('Ymd_His') . '.pdf', [
            'Attachment' => true,
        ]);
    }
}
