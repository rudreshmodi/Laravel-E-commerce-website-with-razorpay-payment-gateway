<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

class UserDetailsController extends Controller
{
    /**
     * Display a listing of users.
     *
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login')->with('error', 'Please log in to access this page.');
        }

        $query = User::withoutTrashed();

        if ($request->filled('search')) {
            $query->where('name', 'like', '%' . $request->search . '%')
                ->orWhere('email', 'like', '%' . $request->search . '%')
                ->orWhere('mobile_number', 'like', '%' . $request->search . '%');
        }

        $users = $query->paginate(10);

        return view('user_details.index', compact('users'));
    }

    /**
     * Display the specified user.
     *
     * @param  int  $id
     * @return \Illuminate\View\View
     */
    public function show($id)
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }

        $user = User::findOrFail($id);
        return view('user_details.show', compact('user'));
    }

    /**
     * Show the form for editing the specified user.
     *
     * @param  int  $id
     * @return \Illuminate\View\View
     */
    public function edit($id)
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }


        $user = User::findOrFail($id);
        return view('user_details.edit', compact('user'));
    }

    /**
     * Update the specified user in the database.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(Request $request, $id)
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }

        // Fetch the user
        $user = User::findOrFail($id);

        // Validation rules
        $validated = $request->validate([
            'role' => 'required|in:admin,user',  // Ensure role is selected and valid
            'name' => 'sometimes|required|string|max:255',
            'email' => 'sometimes|required|email|unique:users,email,' . $user->id,
            'mobile_number' => 'sometimes|required|max:15',
            'password' => 'nullable|min:8',
        ]);

        // Update fields if they are provided in the request
        if ($request->has('role')) {
            $user->role = $request->input('role');
        }
        if ($request->has('name')) {
            $user->name = $request->input('name');
        }
        if ($request->has('email')) {
            $user->email = $request->input('email');
        }
        if ($request->has('mobile_number')) {
            $user->mobile_number = $request->input('mobile_number');
        }
        if ($request->has('password') && $request->input('password') !== '') {
            $user->password = Hash::make($request->input('password'));
        }

        // Save the user
        $user->save();

        // Redirect back with a success message
        return redirect()->route('user_details.index')->with('success', 'User details updated successfully!');
    }

    /**
     * Remove the specified user from the database (soft delete).
     *
     * @param  int  $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function destroy($id)
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }


        $user = User::findOrFail($id);
        $user->delete();

        return redirect()->route('user_details.index')->with('success', 'User soft deleted successfully!');
    }

    /**
     * Restore the soft deleted user.
     *
     * @param  int  $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function restore($id)
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }


        $user = User::withTrashed()->findOrFail($id);
        $user->restore();

        return redirect()->route('user_details.index')->with('success', 'User restored successfully!');
    }

    /**
     * Permanently delete the specified user.
     *
     * @param  int  $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function forceDelete($id)
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }


        $user = User::withTrashed()->findOrFail($id);
        $user->forceDelete();

        return redirect()->route('user_details.index')->with('success', 'User permanently deleted!');
    }

    /**
     * Soft delete the user account.
     *
     * @param  int  $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function softDelete($id)
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }

        $user = User::findOrFail($id);
        $user->deleted_at = Carbon::now(); // Set the deleted_at timestamp
        $user->save();

        return redirect()->route('user_details.index')->with('success', 'User account marked for deletion!');
    }


    public function toggleRole(User $user)
    {

        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }


        $newRole = $user->role === 'admin' ? 'user' : 'admin';
        $user->role = $newRole;
        $user->save();

        return response()->json(['success' => true, 'newRole' => $newRole]);
    }
}
