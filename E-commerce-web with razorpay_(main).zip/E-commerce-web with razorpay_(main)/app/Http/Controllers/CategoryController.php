<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Subcategory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;

class CategoryController extends Controller
{
    /**
     * Display a listing of the categories.
     */
    public function index(Request $request)
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }


        // Start with the base query to get categories
        $query = Category::withoutTrashed();

        // Apply the filter for category name search if provided
        if ($request->filled('search')) {
            $query->where('name', 'like', '%' . $request->search . '%');
        }

        // Get the paginated result
        $categories = $query->paginate(10);

        return view('categories.index', compact('categories'));
    }

    /**
     * Show the form for creating a new category.
     */
    public function create()
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }


        return view('categories.create');
    }

    /**
     * Store a newly created category in storage.
     */
    public function store(Request $request)
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }

        // Validate input data including the 'image' field
        $validated = $request->validate([
            'name' => 'required|string|min:3',
            'description' => 'nullable|string|max:100',
            'image' => 'nullable|image|mimes:jpg,jpeg,png,webp|max:10240', // Max size 10MB (10240 KB)
        ]);

        // Handle the image upload if an image is provided
        if ($request->hasFile('image')) {
            $imagePath = $request->file('image')->store('category_images', 'public');
            $validated['image'] = $imagePath;
        }

        // Create the category with validated data
        Category::create($validated);

        session()->flash('success', 'Category created successfully!');

        return redirect()->route('categories.index');
    }

    /**
     * Display the specified category.
     */
    public function show(Category $category)
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }


        // Fetch products related to the category, including soft-deleted ones, and paginate them
        $products = $category->products()->withTrashed()->paginate(10);

        // Check if the products collection is empty
        if ($products->isEmpty()) {
            return back()->with('error', 'No products found for this category.');
        }

        // Fetch subcategories related to the category, including soft-deleted ones
        $subcategories = $category->subcategories()->withTrashed()->get();

        return view('user.categorywiseproduct', compact('category', 'products', 'subcategories'));
    }


    public function view(Category $category)
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }


        return view('categories.show', compact('category'));
    }

    /**
     * Show the form for editing the specified category.
     */
    public function edit(Category $category)
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }


        return view('categories.edit', compact('category'));
    }

    /**
     * Update the specified category in storage.
     */
    public function update(Request $request, Category $category)
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }


        // Validate input data including the 'image' field
        $validated = $request->validate([
            'name' => 'required|string|min:3',
            'description' => 'nullable|string|max:100',
            'image' => 'nullable|image|mimes:jpg,jpeg,png,webp|max:10240', // Max size 10MB (10240 KB)
        ]);

        // Handle the image upload if an image is provided
        if ($request->hasFile('image')) {
            // Delete old image if exists
            if ($category->image && Storage::exists('public/' . $category->image)) {
                Storage::delete('public/' . $category->image);
            }

            // Store new image and update validated data
            $imagePath = $request->file('image')->store('category_images', 'public');
            $validated['image'] = $imagePath;
        }

        // Update the category with validated data
        $category->update($validated);

        session()->flash('success', 'Category updated successfully!');

        return redirect()->route('categories.index');
    }

    public function destroy(Category $category)
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }


        // Soft delete related products and category
        $category->products()->delete();  // Soft delete products
        $category->delete(); // Soft delete the category

        session()->flash('success', 'Category and its products deleted successfully!');

        return redirect()->route('categories.index');
    }

    public function restore($id)
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }


        // Find the category including soft-deleted ones
        $category = Category::withTrashed()->findOrFail($id);

        // Restore the category and its products
        $category->restore();
        $category->products()->withTrashed()->restore(); // Restore soft-deleted products

        session()->flash('success', 'Category and its products restored successfully!');

        return redirect()->route('categories.index');
    }


    /**
     * Display all products belonging to the specified category.
     */
    public function viewProducts(Category $category)
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }


        // Debug: Check if category exists and fetch related products
        if (!$category) {
            abort(404, 'Category not found.');
        }

        $products = $category->products()->withTrashed()->paginate(10);

        if ($products->isEmpty()) {
            return back()->with('error', 'No products found for this category.');
        }

        return view('categories.products', compact('category', 'products'));
    }

    public function viewSubcategories(Category $category)
    {
        // Check if the user is authenticated
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }


        // Debug: Check if category exists
        if (!$category) {
            abort(404, 'Category not found.');
        }

        // Fetch the subcategories for the given category (including soft deleted ones)
        $subcategories = $category->subcategories()->withTrashed()->paginate(10);

        // Check if subcategories exist for the given category
        if ($subcategories->isEmpty()) {
            return back()->with('error', 'No subcategories found for this category.');
        }

        // Return the view with the category and its subcategories
        return view('categories.subcategories', compact('category', 'subcategories'));
    }
}
