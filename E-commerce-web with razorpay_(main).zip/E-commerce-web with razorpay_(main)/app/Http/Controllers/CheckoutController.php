<?php

namespace App\Http\Controllers;

use App\Mail\OrderPlaced;
use App\Mail\PaymentSuccess;
use App\Models\CartItem;
use App\Models\Order;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\DB;

class CheckoutController extends Controller
{
    /**
     * Show the checkout page with cart items.
     */
    public function index()
    {
        if (!Auth::check() || Auth::user()->role !== 'user') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }
        // Get cart items for the authenticated user
        $cartItems = CartItem::where('user_id', Auth::id())->get();

        // Calculate the total of the cart items
        $total = $cartItems->sum(function ($item) {
            return $item->product->price * $item->quantity;
        });

        // Check if total is less than 300, then add a shipping fee
        $shippingFee = ($total < 300) ? 25 : 0;

        // Calculate the final total including shipping
        $finalTotal = $total + $shippingFee;

        // Get categories from cart items to fetch recommended products
        $categories = $cartItems->map(function ($item) {
            return $item->product->category_id;
        })->unique();

        // Fetch recommended products based on categories
        $recommendedProducts = Product::whereIn('category_id', $categories)
            ->whereNotIn('id', $cartItems->pluck('product_id'))
            ->limit(8)
            ->get();

        // Pass variables to the view
        return view('user.checkout', compact('cartItems', 'total', 'shippingFee', 'finalTotal', 'recommendedProducts'));
    }

    /**
     * Handle Cash on Delivery checkout.
     */
    public function codCheckout(Request $request)
    {
        if (!Auth::check() || Auth::user()->role !== 'user') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }
        // Ensure the cart exists
        $cartItems = CartItem::where('user_id', Auth::id())->get();

        // Check if the cart is empty
        if ($cartItems->isEmpty()) {
            // Redirect to cart page with an error message if the cart is empty
            return redirect()->route('user.cart')->with('error', 'Your cart is empty.');
        }

        // Calculate the total price and add shipping fee
        $total = $cartItems->sum(function ($item) {
            return $item->product->price * $item->quantity;
        });
        $shippingFee = ($total < 300) ? 25 : 0;
        $finalTotal = $total + $shippingFee;

        // Prepare the comma-separated list of product IDs
        $productIds = $cartItems->map(function ($item) {
            return $item->product->id;
        })->toArray(); // Collect all product IDs

        // Create the order with 'cash on delivery' status
        $order = Order::create([
            'user_id' => Auth::id(),
            'total' => $finalTotal,  // Include shipping fee in the final total
            'status' => 'cash on delivery',
            'address' => $request->address,
            'product_id' => implode(",", $productIds), // Store comma-separated product IDs
        ]);

        // Prepare comma-separated details for the products in the cart
        $productNames = [];
        $productImages = [];
        $quantities = [];
        $prices = [];

        foreach ($cartItems as $item) {
            $productNames[] = $item->product->name;
            $productImages[] = asset('storage/' . $item->product->image); // Use correct path or URL for the image
            $quantities[] = $item->quantity;
            $prices[] = $item->product->price;
        }

        // Save these details to the order
        $order->order_items = implode(",", $productNames);
        $order->order_images = implode(",", $productImages);  // Store full image URLs
        $order->order_quantities = implode(",", $quantities);
        $order->order_prices = implode(",", $prices);

        $order->save();

        // Clear the user's cart after placing the order
        CartItem::where('user_id', Auth::id())->delete();
        DB::statement('ALTER TABLE cart_items AUTO_INCREMENT = 1;');

        // Send confirmation email
        Mail::to(Auth::user()->email)->send(new OrderPlaced($order));
        Mail::to(Auth::user()->email)->send(new PaymentSuccess($order));  // Send payment success email for COD

        // Return a success view or redirect to a confirmation page
        return redirect()->route('user.checkout')->with('success', 'Order placed successfully with Cash on Delivery.');
    }

    /**
     * Process payment with Stripe.
     */
    public function process(Request $request)
    {
        if (!Auth::check() || Auth::user()->role !== 'user') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }

        $cartItems = CartItem::where('user_id', Auth::id())->get();
        $productIds = $cartItems->map(function ($item) {
            return $item->product->id;
        })->toArray();

        if ($cartItems->isEmpty()) {
            return redirect()->route('user.cart')->with('error', 'Your cart is empty.');
        }

        $total = $cartItems->sum(function ($item) {
            return $item->product->price * $item->quantity;
        });
        $shippingFee = ($total < 300) ? 25 : 0;
        $finalTotal = $total + $shippingFee;

        if ($request->payment_method == 'cod') {
            return $this->codCheckout($request);
        }

        // Handle Razorpay checkout
        if ($request->payment_method == 'razorpay') {
            // Create Razorpay Order
            $api = new \Razorpay\Api\Api(env('RAZORPAY_KEY'), env('RAZORPAY_SECRET'));
            $orderData = [
                'receipt'         => (string) rand(1000, 9999), // Ensure receipt is a string
                'amount'          => (int) ($finalTotal * 100), // Amount in paise, ensure it's an integer
                'currency'        => 'INR',
                'payment_capture' => 1 // Auto capture
            ];
            $razorpayOrder = $api->order->create($orderData);

            // Create an order with status 'pending' without storing Razorpay data
            $order = Order::create([
                'user_id' => Auth::id(),
                'total' => (float) $finalTotal, // Ensure total is a float
                'status' => 'pending',
                'address' => (string) $request->address, // Ensure address is a string
                'product_id' => implode(",", $productIds), // Store comma-separated product IDs
                // Removed razorpay_order_id and any other Razorpay-specific fields
            ]);

            // Prepare details for the cart
            $productNames = [];
            $productImages = [];
            $quantities = [];
            $prices = [];
            foreach ($cartItems as $item) {
                $productNames[] = $item->product->name;
                $productImages[] = asset('storage/' . $item->product->image);
                $quantities[] = $item->quantity;
                $prices[] = $item->product->price;
            }

            // Save details in the order
            $order->order_items = implode(",", $productNames);
            $order->order_images = implode(",", $productImages);
            $order->order_quantities = implode(",", $quantities);
            $order->order_prices = implode(",", $prices);
            $order->save();

            // Return Razorpay order details to the view
            return view('user.razorpay', compact('razorpayOrder', 'finalTotal'));
        }

        return redirect()->route('user.checkout')->with('error', 'Invalid payment method.');
    }

    /**
     * Handle successful payment.
     */
    /**
     * Handle successful payment.
     */
    public function success(Request $request)
    {
        if (!Auth::check() || Auth::user()->role !== 'user') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not a user
        }

        // Find the latest 'pending' order for the authenticated user
        $order = Order::where('user_id', Auth::id())
            ->where('status', 'pending')
            ->latest()
            ->first();

        if (!$order) {
            return redirect()->route('user.cart')->with('error', 'No pending order found.');
        }

        // Update the order status to 'paid'
        $order->status = 'paid';

        // Store Razorpay payment details (if payment was done via Razorpay)
        if ($request->has('razorpay_payment_id') && $request->has('razorpay_order_id') && $request->has('razorpay_signature')) {
            $order->razorpay_payment_id = $request->razorpay_payment_id;
            $order->razorpay_order_id = $request->razorpay_order_id;
            $order->razorpay_signature = $request->razorpay_signature;
        }

        // Optionally, store other payment details or transaction info
        $order->payment_status = 'successful';  // You can use this field to track the payment status
        $order->payment_method = 'razorpay';  // Or store 'cod' if it's a Cash on Delivery payment
        $order->payment_details = json_encode([
            'payment_id' => $request->razorpay_payment_id ?? 'N/A',
            'order_id' => $request->razorpay_order_id ?? 'N/A',
            'signature' => $request->razorpay_signature ?? 'N/A',
            'amount' => $order->total,  // Store the total paid amount
        ]);

        $order->save();

        // Send confirmation emails after successful payment
        Mail::to(Auth::user()->email)->send(new OrderPlaced($order));
        Mail::to(Auth::user()->email)->send(new PaymentSuccess($order));

        // Clear the user's cart after the successful payment
        CartItem::where('user_id', Auth::id())->delete();
        DB::statement('ALTER TABLE cart_items AUTO_INCREMENT = 1;');

        // Redirect the user to a success page or confirmation page
        return redirect()->route('user.checkout')
            ->with('success', 'Your payment was successful. Your order has been placed.');
    }

    /**
     * Handle canceled payment.
     */
    public function cancel()
    {
        if (!Auth::check() || Auth::user()->role !== 'user') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }

        $order = Order::where('user_id', Auth::id())
            ->where('status', 'pending')
            ->latest()
            ->first();

        if ($order) {
            $order->update(['status' => 'cancelled']);
        }

        return view('user.cancel', compact('order'));
    }
}