<?php

namespace App\Notifications;

use App\Models\ContactUs;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Notification;
use Illuminate\Notifications\Messages\MailMessage;

class ReplyToContactUsNotification extends Notification implements ShouldQueue
{
    use Queueable;

    protected $contactUs;
    protected $reply;

    // Constructor to accept the contact submission and the reply
    public function __construct(ContactUs $contactUs, $reply)
    {
        $this->contactUs = $contactUs;
        $this->reply = $reply;
    }

    // Define which channels the notification will be sent through
    public function via($notifiable)
    {
        return ['mail']; // Sending the notification via email
    }

    // Build the mail message to send
    public function toMail($notifiable)
    {
        return (new MailMessage)
            ->subject('Reply to Your Message')
            ->markdown('emails.contactus.reply', [
                'contactUs' => $this->contactUs, // Original contact message
                'reply' => $this->reply,         // The reply message
            ]);
    }

    // Optional: You can also define the `toArray` method to store notification data in the database
    public function toArray($notifiable)
    {
        return [
            'contact_us_id' => $this->contactUs->id,
            'reply' => $this->reply,
        ];
    }
}