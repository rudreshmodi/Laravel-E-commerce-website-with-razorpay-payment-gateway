<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CartItem extends Model
{
    use HasFactory;

    // Define the fillable attributes for mass assignment
    protected $fillable = ['user_id', 'product_id', 'quantity'];

    /**
     * Define the relationship to the Product model.
     * This assumes that the CartItem belongs to a Product.
     */
    public function product()
    {
        return $this->belongsTo(Product::class); // Each cart item is associated with a product
    }

    /**
     * Define the relationship to the User model.
     * This assumes that the CartItem belongs to a User.
     */
    public function user()
    {
        return $this->belongsTo(User::class); // Each cart item belongs to a user
    }

    /**
     * Define the relationship to Order (if applicable).
     * If you're using orders, this relationship is useful for tracking orders that include cart items.
     */
    public function order()
    {
        return $this->belongsTo(Order::class, 'order_id'); // Assuming CartItems can belong to an Order
    }

    // Optional: Define the accessors and mutators if needed for any custom behavior, like prices or computed values
}
