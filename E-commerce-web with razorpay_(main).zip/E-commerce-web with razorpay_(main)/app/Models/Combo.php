<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes; // Import SoftDeletes trait

class Combo extends Model
{
    use HasFactory, SoftDeletes; // Use SoftDeletes trait for soft deletes

    // Define the $fillable property to allow mass assignment on the specified columns
    protected $fillable = [
        'name',
        'description',
        'total_price',
        'disc_price',
        'image',
        'categories_id',  // Match the database column 'categories_id'
        'subcategories_id' // Match the database column 'subcategories_id'
    ];

    // Automatically manage the 'deleted_at' field for soft deletes
    protected $dates = ['deleted_at'];

    // Relationship with the 'categories' table (corrected to match the column name 'categories_id')
    public function category()
    {
        return $this->belongsTo(Category::class, 'categories_id'); // The foreign key is 'categories_id'
    }

    // Relationship with the 'subcategories' table (corrected to match the column name 'subcategories_id')
    public function subcategory()
    {
        return $this->belongsTo(Subcategory::class, 'subcategories_id'); // The foreign key is 'subcategories_id'
    }

    // Many-to-many relationship with products via a pivot table ('combo_product')
    public function products()
    {
        return $this->belongsToMany(Product::class, 'combo_product'); // Pivot table 'combo_product'
    }

    // Accessor for formatted total price (formatted as currency)
    public function getFormattedTotalPriceAttribute()
    {
        return number_format($this->total_price, 2); // Format as 2 decimal places
    }

    // Accessor for formatted discount price (formatted as currency)
    public function getFormattedDiscPriceAttribute()
    {
        return $this->disc_price ? number_format($this->disc_price, 2) : null; // Format if discount exists
    }
}